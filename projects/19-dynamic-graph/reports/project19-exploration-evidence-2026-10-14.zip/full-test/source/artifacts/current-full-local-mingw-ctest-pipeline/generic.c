int transform(const double *a,double *l,int n) {
  int i=0;
  while(i<n*n) {
    if(i<n*n && a[i]>=0.0) l[i]=a[i]/2.0;
    else l[i]=-a[i];
    i=i+1;
  }
  return 0;
}
