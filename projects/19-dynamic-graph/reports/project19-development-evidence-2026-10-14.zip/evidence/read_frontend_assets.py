from pathlib import Path
import re,urllib.request,json
r=Path(__file__).resolve().parent/'official';s=(r/'frontend.html').read_text(encoding='utf-8')
urls=list(dict.fromkeys(re.findall(r'https://www.chaspark.com/pkg/chaspark-frontend-portal/[^\s"<>]+[.]js',s)))
print(json.dumps(urls),flush=True)
for i,u in enumerate(urls):
 with urllib.request.urlopen(u,timeout=20) as f:b=f.read()
 p=r/f'frontend-{i}.js';p.write_bytes(b);print(p.name,len(b),flush=True)
 s2=b.decode('utf-8')
 for term in ('competitions','competitionDetail','races','/api/','getCompetition','baseURL'):
  k=s2.find(term)
  if k>=0:print(term,s2[max(0,k-170):k+350],flush=True)
