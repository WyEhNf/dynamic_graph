from pathlib import Path
import datetime,hashlib,json,urllib.request,urllib.error
r=Path(__file__).resolve().parent/'official'
u='https://www.chaspark.com/chasiwu/v1/content/races/question/detail?nid=1326691788365586432'
req=urllib.request.Request(u,headers={'User-Agent':'Mozilla/5.0','Referer':'https://www.chaspark.com/','Accept':'application/json'})
try:
 with urllib.request.urlopen(req,timeout=30) as f:b=f.read()
 (r/'question-response.json').write_bytes(b)
 print(b.decode('utf-8')[:24000],flush=True)
 (r/'question-provenance.json').write_text(json.dumps(dict(url=u,fetched_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),endpoint_source='Public frontend main.f06855d3.js getCompetitionsApi'),indent=2)+'\n',encoding='utf-8')
except urllib.error.HTTPError as e:
 print(e.code,e.read().decode('utf-8')[:1000],flush=True)
