static long long h(double x){return x;}
int transform(const double*a,double*l,int n){l[0]=h(a[0]);return 0;}