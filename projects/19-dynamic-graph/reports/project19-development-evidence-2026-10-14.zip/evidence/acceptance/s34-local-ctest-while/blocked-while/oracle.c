#include <stdint.h>
#include <stdio.h>
#include "G:/Hackathon-stage2-artifacts/project19/20261014-development/acceptance/s34-local-ctest-while/blocked-while.c"

/* stdlib declarations avoid conflicting with the official image's div helper. */
extern void *calloc(size_t,size_t);
extern void free(void *);
extern int atoi(const char *);
int main(int argc, char **argv) {
  if(argc != 4) return 10;
  FILE *in=fopen(argv[1],"rb"), *out=fopen(argv[2],"wb");
  if(!in || !out) return 11;
  int block=atoi(argv[3]); uint32_t m;
  if(fread(&m,4,1,in)!=1 || fwrite(&m,4,1,out)!=1) return 12;
  for(uint32_t z=0;z<m;z++) {
    uint32_t n; if(fread(&n,4,1,in)!=1 || n<3 || n>10000) return 13;
    size_t count=(size_t)n*n;
    double *a=(double*)calloc(count,sizeof(double)), *l=(double*)calloc(count,sizeof(double));
    if(!a || !l || fread(a,sizeof(double),count,in)!=count) return 14;
    factor(a,l,(int)n,block);
    if(fwrite(&n,4,1,out)!=1 || fwrite(l,sizeof(double),count,out)!=count) return 15;
    free(a); free(l);
  }
  if(fgetc(in)!=EOF) return 16;
  fclose(in); if(fclose(out)) return 17; return 0;
}
