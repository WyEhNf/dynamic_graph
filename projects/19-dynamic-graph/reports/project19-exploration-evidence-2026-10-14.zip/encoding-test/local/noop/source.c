int noop(const double *a,double *l,int n){return 0;}
