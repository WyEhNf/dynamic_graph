from pathlib import Path
import json,subprocess
r=Path('F:/Hackathon')
x=subprocess.run(['git','-C',str(r),'ls-files','--others','--exclude-standard','-z'],capture_output=True,check=True)
rows=[dict(path=n.decode('utf-8'),bytes=(r/n.decode('utf-8')).stat().st_size) for n in x.stdout.split(b'\0') if n]
Path(__file__).with_name('git-inventory.json').write_text(json.dumps(rows,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
print(json.dumps(dict(files=len(rows),total_bytes=sum(x['bytes'] for x in rows),largest=sorted(rows,key=lambda x:x['bytes'],reverse=True)[:22]),ensure_ascii=False))
