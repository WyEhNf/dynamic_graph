"""Full registered regression of frozen installed S33, fresh builds on G."""
from pathlib import Path
import datetime,hashlib,json,os,shutil,subprocess,time,xml.etree.ElementTree as ET
ROOT=Path(__file__).resolve().parent
PROJECT=Path('F:/Hackathon/projects/19-dynamic-graph')
S33=Path('G:/Hackathon-stage2-artifacts/project19/20261013-overnight/structured-owned-reuse')
OUT=ROOT/'full-test';OUT.mkdir(parents=True,exist_ok=True)
assert not (OUT/'report.json').exists(),'Do not overwrite or restart a test batch'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
gate=json.loads((S33/'composition-gate.json').read_text(encoding='utf-8'))
installed=json.loads((S33/'installed-runtime.json').read_text(encoding='utf-8'))
assert sha(installed['runtime']['path'])==installed['runtime']['sha256']=='912c9fec8ac5e1793d6217afc5c3b09f49a8b8e536f273eeaef9b94a69072eba'
assert sha(installed['core']['path'])==installed['core']['sha256']=='e7c9dd7fa08ecff90318762fd3bef95e816f7918e85e9ec2274bebca21c3b3c6'
ws=OUT/'source';assert not ws.exists();ws.mkdir()
for name,h in gate['source_sha256'].items():
    src=PROJECT/name;assert sha(src)==h,name
    dst=ws/name;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst)
for name in ('README.md','docs/requirements.md','docs/metadata.md','docs/development-plan.md','docs/stage-metrics-2026-10-13.md'):
    dst=OUT/'documentation'/name;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(PROJECT/name,dst)
tmp=OUT/'tmp';tmp.mkdir()
env=dict(os.environ,PATH='E:/mingw64/bin;'+os.environ.get('PATH',''),TEMP=str(tmp),TMP=str(tmp),PYTHONIOENCODING='utf-8',PYTHONUTF8='1')
cmake='C:/Program Files (x86)/CMake/bin/cmake.exe';ctest='C:/Program Files (x86)/CMake/bin/ctest.exe'
report=dict(status='running',started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_count=len(gate['source_sha256']),source_sha256=gate['source_sha256'],
    installed_runtime=installed['runtime'],installed_core=installed['core'],composition_gate_sha256=sha(S33/'composition-gate.json'),
    scope='All registered tests of actual local-mingw and memory-mingw presets from fresh frozen206-source builds. Historical optional/negative experimental branches are not counted as current production capabilities.',
    profiles=[],active_stage='prepare',commands=[])
def save():(OUT/'report.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
save()
for profile in ('local-mingw','memory-mingw'):
    build=OUT/('build-'+profile)
    row=dict(profile=profile,build=str(build),status='running');report['profiles'].append(row)
    cmds=[('configure',[cmake,'--preset',profile,'-S',str(ws),'-B',str(build),'-DCMAKE_MAKE_PROGRAM=E:/mingw64/bin/mingw32-make.exe',
        '-DPython3_EXECUTABLE=F:/Hackathon/projects/19-dynamic-graph/.venv/Scripts/python.exe','-DCHOL_CLANG_EXECUTABLE=C:/Program Files/LLVM/bin/clang.exe',
        '-DCHOL_TEST_ARTIFACT_LABEL=current-full-'+profile]),
        ('build',[cmake,'--build',str(build),'-j3']),
        ('inventory',[ctest,'--test-dir',str(build),'--show-only=json-v1']),
        ('ctest',[ctest,'--test-dir',str(build),'--output-on-failure','--output-junit',str(OUT/(profile+'-junit.xml'))])]
    for label,cmd in cmds:
        report['active_stage']=profile+'/'+label;save();print('BEGIN '+report['active_stage'],flush=True)
        start=time.perf_counter();p=subprocess.run(cmd,cwd=ws,env=env,capture_output=True,text=True);seconds=time.perf_counter()-start
        log=OUT/(profile+'-'+label+'.log');log.write_text(p.stdout+p.stderr,encoding='utf-8')
        rec=dict(profile=profile,stage=label,command=cmd,returncode=p.returncode,seconds=seconds,log=str(log),log_sha256=sha(log));report['commands'].append(rec);save()
        assert p.returncode==0,(profile,label,p.stderr,p.stdout[-2000:])
        if label=='inventory':
            inventory=json.loads(p.stdout);row['registered_tests']=[t['name'] for t in inventory['tests']];save()
    xml=ET.parse(OUT/(profile+'-junit.xml')).getroot()
    tests=list(xml.iter('testcase'))
    failures=[t.attrib.get('name') for t in tests if t.find('failure') is not None or t.find('error') is not None]
    skipped=[t.attrib.get('name') for t in tests if t.find('skipped') is not None]
    assert len(tests)==len(row['registered_tests']) and not failures and not skipped,(failures,skipped)
    row.update(status='completed',passed=True,tests=len(tests),failures=failures,skipped=skipped,junit_sha256=sha(OUT/(profile+'-junit.xml')),
        fresh_runtime_sha256=sha(build/'cholesky_runtime.exe'),fresh_core_sha256=sha(build/'libcholesky_core.a'),flags_sha256=sha(build/'CMakeFiles/cholesky_core.dir/flags.make'))
    save();print(json.dumps(dict(profile=profile,passed=True,tests=row['tests'])),flush=True)
for name,h in gate['source_sha256'].items():assert sha(PROJECT/name)==sha(ws/name)==h,name
assert sha(installed['runtime']['path'])==installed['runtime']['sha256']
report.update(status='completed',passed=True,total_registered_tests=sum(r['tests'] for r in report['profiles']),finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),active_stage=None)
save();print(json.dumps(dict(passed=True,total_tests=report['total_registered_tests'],production_modified=False)),flush=True)
