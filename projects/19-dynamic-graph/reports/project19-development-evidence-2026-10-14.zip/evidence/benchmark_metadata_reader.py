from pathlib import Path
import datetime,hashlib,json,os,statistics,subprocess
ROOT=Path(__file__).resolve().parent;OUT=ROOT/'reader-screen';OUT.mkdir(exist_ok=True)
assert not (OUT/'report.json').exists()
P=Path('F:/Hackathon/projects/19-dynamic-graph');old=Path('G:/Hackathon-stage2-artifacts/project19/20261014-exploration/full-test/build-local-mingw');new=ROOT/'build'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
env=dict(os.environ,PATH='E:/mingw64/bin;'+os.environ.get('PATH',''),TEMP=str(OUT),TMP=str(OUT))
for name,build in [('baseline',old),('candidate',new)]:
 cmd=['E:/mingw64/bin/g++.exe','-std=c++20','-O3','-fno-fast-math','-ffp-contract=off','-I'+str(P/'include'),str(ROOT/'metadata_load_probe.cpp'),str(build/'libcholesky_core.a'),'-pthread','-o',str(OUT/(name+'.exe'))]
 x=subprocess.run(cmd,env=env,capture_output=True,text=True);assert x.returncode==0,x.stderr
plan=dict(pairs=7,iterations=1024,order='AB/BA alternation; one first read outside timer in each fresh process',scope='Same actual Cholesky Metadata; hot repeated full reader including open/read/parse/close/destruction. Separate from whole compute and cold process startup.',gate='All3 primary schema3/table cases median paired load reduction>=10%; named schema2 controls median regression<=5%. All samples retained.')
r=dict(status='running',started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),plan=plan,core_sha256=dict(baseline=sha(old/'libcholesky_core.a'),candidate=sha(new/'libcholesky_core.a')),records=[],summary=[])
def save():(OUT/'report.json').write_text(json.dumps(r,indent=2)+'\n',encoding='utf-8')
save()
for source in ('scalar','page','blocked'):
 for wire in ('3-table','2-dag'):
  meta=ROOT/'metadata-screen'/source/(wire+'.meta');label=source+'/'+wire
  for pair in range(7):
   for variant in (('baseline','candidate') if pair%2==0 else ('candidate','baseline')):
    cmd=[str(OUT/(variant+'.exe')),str(meta),'1024'];x=subprocess.run(cmd,env=env,capture_output=True,text=True);assert x.returncode==0,x.stderr
    m=json.loads(x.stdout);r['records'].append(dict(case=label,pair=pair,variant=variant,metadata_sha256=sha(meta),metrics=m));save()
  rows=[x for x in r['records'] if x['case']==label];base=[x['metrics'] for x in rows if x['variant']=='baseline'];cand=[x['metrics'] for x in rows if x['variant']=='candidate'];assert len({x['parsed_hash'] for x in base+cand})==1 and len({x['observed'] for x in base+cand})==1
  ratios=[100*(1-c['milliseconds']/b['milliseconds']) for b,c in zip(base,cand)]
  rec=dict(case=label,baseline_median_ms=statistics.median(x['milliseconds'] for x in base),candidate_median_ms=statistics.median(x['milliseconds'] for x in cand),paired_reductions_percent=ratios,median_paired_reduction_percent=statistics.median(ratios),wins=sum(x>0 for x in ratios));r['summary'].append(rec);save();print(json.dumps(rec),flush=True)
r.update(status='completed',passed=True,gate_passed=all(x['median_paired_reduction_percent']>=10 if '/3-' in x['case'] else x['median_paired_reduction_percent']>=-5 for x in r['summary']),finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());save();print(json.dumps(dict(passed=True,gate=r['gate_passed'])),flush=True)
