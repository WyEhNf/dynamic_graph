int transform(const double*a,double*l,int n){
for(int i=0;i<n*n;++i){
  if(i%4==0)l[i]=-i;
  else if(i%4==1)l[i]=(-i)/n;
  else if(i%4==2)l[i]=(-i)%2;
  else l[i]=(-i)*0;
}return 0;}
