from pathlib import Path
import datetime,hashlib,json,os,shutil,sys
ROOT=Path(__file__).resolve().parent;P=Path('F:/Hackathon/projects/19-dynamic-graph');OUT=ROOT/'metadata-screen';OUT.mkdir(exist_ok=True)
sys.path.insert(0,str(P/'tools'));from analyze_source import PreparedSource
from test_smallest_metadata_stage2 import expanded
os.environ.update(PATH='E:/mingw64/bin;C:/Program Files/LLVM/bin;'+os.environ.get('PATH',''),TEMP=str(OUT),TMP=str(OUT))
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
rows=[]
for label,source,fn in [('scalar',P/'fixtures/cholesky_reference.c','cholesky_reference'),('page',P/'fixtures/official_naive_transcribed.c','cholesky'),('blocked',P/'fixtures/cholesky_blocked.c','cholesky_blocked')]:
 folder=OUT/label;folder.mkdir();prepared=PreparedSource(source,'C:/Program Files/LLVM/bin/clang.exe');variants=[];graphs=[]
 for schema in (2,3):
  for mode in ('dag','table','expanded','packed'):
   target=folder/f'{schema}-{mode}.meta';a=prepared.emit(target,function=fn,metadata_schema=schema,symbolic_format=mode,emit_ir=False);variants.append(dict(schema=schema,mode=mode,bytes=target.stat().st_size,sha256=sha(target),path=str(target)));graphs.append(expanded(target))
 assert all(g==graphs[0] for g in graphs)
 minimum=folder/'minimum.meta';a=prepared.emit(minimum,function=fn,smallest_metadata=True,emit_ir=False)
 old=min((x for x in variants if x['mode']!='packed'),key=lambda x:x['bytes']);new=min(variants,key=lambda x:x['bytes']);assert sha(minimum)==new['sha256']
 row=dict(source=label,source_path=str(source),source_sha256=sha(source),function=fn,variants=variants,old_minimum=old,new_minimum=new,minimum_bytes_saved=old['bytes']-new['bytes'],minimum_reduction_percent=100*(1-new['bytes']/old['bytes']),complete_graph_program_header_identical=True)
 rows.append(row);print(json.dumps(row),flush=True)
report=dict(passed=True,created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='Primary actual Cholesky sources only; static complete Metadata equality and byte sizes, not runtime correctness or speed yet.',sources=rows)
(OUT/'size-report.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
