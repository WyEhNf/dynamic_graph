; ModuleID = 'G:\Hackathon-stage2-artifacts\project19\20261014-development\acceptance\s34-local-ctest-helpers\cholesky-unused-integer-local.c'
source_filename = "G:\\Hackathon-stage2-artifacts\\project19\\20261014-development\\acceptance\\s34-local-ctest-helpers\\cholesky-unused-integer-local.c"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-windows-msvc19.44.35228"

; Function Attrs: noinline nounwind optnone uwtable
define dso_local void @cholesky(ptr noundef %0, ptr noundef %1, i32 noundef %2) #0 {
  %4 = alloca i32, align 4
  %5 = alloca ptr, align 8
  %6 = alloca ptr, align 8
  %7 = alloca i32, align 4
  %8 = alloca i32, align 4
  %9 = alloca i32, align 4
  store i32 %2, ptr %4, align 4
  store ptr %1, ptr %5, align 8
  store ptr %0, ptr %6, align 8
  store i32 0, ptr %7, align 4
  br label %10

10:                                               ; preds = %138, %3
  %11 = load i32, ptr %7, align 4
  %12 = load i32, ptr %4, align 4
  %13 = icmp slt i32 %11, %12
  br i1 %13, label %14, label %141

14:                                               ; preds = %10
  %15 = load ptr, ptr %6, align 8
  %16 = load i32, ptr %7, align 4
  %17 = load i32, ptr %4, align 4
  %18 = mul nsw i32 %16, %17
  %19 = load i32, ptr %7, align 4
  %20 = add nsw i32 %18, %19
  %21 = sext i32 %20 to i64
  %22 = getelementptr inbounds double, ptr %15, i64 %21
  %23 = load double, ptr %22, align 8
  %24 = load ptr, ptr %5, align 8
  %25 = load i32, ptr %7, align 4
  %26 = load i32, ptr %4, align 4
  %27 = mul nsw i32 %25, %26
  %28 = load i32, ptr %7, align 4
  %29 = add nsw i32 %27, %28
  %30 = sext i32 %29 to i64
  %31 = getelementptr inbounds double, ptr %24, i64 %30
  %32 = load double, ptr %31, align 8
  %33 = fsub double %23, %32
  %34 = call double @sqrt(double noundef %33) #2
  %35 = load ptr, ptr %5, align 8
  %36 = load i32, ptr %7, align 4
  %37 = load i32, ptr %4, align 4
  %38 = mul nsw i32 %36, %37
  %39 = load i32, ptr %7, align 4
  %40 = add nsw i32 %38, %39
  %41 = sext i32 %40 to i64
  %42 = getelementptr inbounds double, ptr %35, i64 %41
  store double %34, ptr %42, align 8
  %43 = load i32, ptr %7, align 4
  %44 = add nsw i32 %43, 1
  store i32 %44, ptr %8, align 4
  br label %45

45:                                               ; preds = %134, %14
  %46 = load i32, ptr %8, align 4
  %47 = load i32, ptr %4, align 4
  %48 = icmp slt i32 %46, %47
  br i1 %48, label %49, label %137

49:                                               ; preds = %45
  %50 = load ptr, ptr %5, align 8
  %51 = load i32, ptr %7, align 4
  %52 = load i32, ptr %4, align 4
  %53 = mul nsw i32 %51, %52
  %54 = load i32, ptr %7, align 4
  %55 = add nsw i32 %53, %54
  %56 = sext i32 %55 to i64
  %57 = getelementptr inbounds double, ptr %50, i64 %56
  %58 = load double, ptr %57, align 8
  %59 = load ptr, ptr %6, align 8
  %60 = load i32, ptr %8, align 4
  %61 = load i32, ptr %4, align 4
  %62 = mul nsw i32 %60, %61
  %63 = load i32, ptr %7, align 4
  %64 = add nsw i32 %62, %63
  %65 = sext i32 %64 to i64
  %66 = getelementptr inbounds double, ptr %59, i64 %65
  %67 = load double, ptr %66, align 8
  %68 = load ptr, ptr %5, align 8
  %69 = load i32, ptr %8, align 4
  %70 = load i32, ptr %4, align 4
  %71 = mul nsw i32 %69, %70
  %72 = load i32, ptr %7, align 4
  %73 = add nsw i32 %71, %72
  %74 = sext i32 %73 to i64
  %75 = getelementptr inbounds double, ptr %68, i64 %74
  %76 = load double, ptr %75, align 8
  %77 = fsub double %67, %76
  %78 = call double @div(double noundef %77, double noundef %58)
  %79 = load ptr, ptr %5, align 8
  %80 = load i32, ptr %8, align 4
  %81 = load i32, ptr %4, align 4
  %82 = mul nsw i32 %80, %81
  %83 = load i32, ptr %7, align 4
  %84 = add nsw i32 %82, %83
  %85 = sext i32 %84 to i64
  %86 = getelementptr inbounds double, ptr %79, i64 %85
  store double %78, ptr %86, align 8
  %87 = load i32, ptr %7, align 4
  %88 = add nsw i32 %87, 1
  store i32 %88, ptr %9, align 4
  br label %89

89:                                               ; preds = %130, %49
  %90 = load i32, ptr %9, align 4
  %91 = load i32, ptr %8, align 4
  %92 = icmp sle i32 %90, %91
  br i1 %92, label %93, label %133

93:                                               ; preds = %89
  %94 = load ptr, ptr %5, align 8
  %95 = load i32, ptr %8, align 4
  %96 = load i32, ptr %4, align 4
  %97 = mul nsw i32 %95, %96
  %98 = load i32, ptr %9, align 4
  %99 = add nsw i32 %97, %98
  %100 = sext i32 %99 to i64
  %101 = getelementptr inbounds double, ptr %94, i64 %100
  %102 = load double, ptr %101, align 8
  %103 = load ptr, ptr %5, align 8
  %104 = load i32, ptr %9, align 4
  %105 = load i32, ptr %4, align 4
  %106 = mul nsw i32 %104, %105
  %107 = load i32, ptr %7, align 4
  %108 = add nsw i32 %106, %107
  %109 = sext i32 %108 to i64
  %110 = getelementptr inbounds double, ptr %103, i64 %109
  %111 = load double, ptr %110, align 8
  %112 = load ptr, ptr %5, align 8
  %113 = load i32, ptr %8, align 4
  %114 = load i32, ptr %4, align 4
  %115 = mul nsw i32 %113, %114
  %116 = load i32, ptr %7, align 4
  %117 = add nsw i32 %115, %116
  %118 = sext i32 %117 to i64
  %119 = getelementptr inbounds double, ptr %112, i64 %118
  %120 = load double, ptr %119, align 8
  %121 = call double @madd(double noundef %120, double noundef %111, double noundef %102)
  %122 = load ptr, ptr %5, align 8
  %123 = load i32, ptr %8, align 4
  %124 = load i32, ptr %4, align 4
  %125 = mul nsw i32 %123, %124
  %126 = load i32, ptr %9, align 4
  %127 = add nsw i32 %125, %126
  %128 = sext i32 %127 to i64
  %129 = getelementptr inbounds double, ptr %122, i64 %128
  store double %121, ptr %129, align 8
  br label %130

130:                                              ; preds = %93
  %131 = load i32, ptr %9, align 4
  %132 = add nsw i32 %131, 1
  store i32 %132, ptr %9, align 4
  br label %89, !llvm.loop !8

133:                                              ; preds = %89
  br label %134

134:                                              ; preds = %133
  %135 = load i32, ptr %8, align 4
  %136 = add nsw i32 %135, 1
  store i32 %136, ptr %8, align 4
  br label %45, !llvm.loop !10

137:                                              ; preds = %45
  br label %138

138:                                              ; preds = %137
  %139 = load i32, ptr %7, align 4
  %140 = add nsw i32 %139, 1
  store i32 %140, ptr %7, align 4
  br label %10, !llvm.loop !11

141:                                              ; preds = %10
  ret void
}

; Function Attrs: nounwind
declare dso_local double @sqrt(double noundef) #1

; Function Attrs: noinline nounwind optnone uwtable
define internal double @div(double noundef %0, double noundef %1) #0 {
  %3 = alloca double, align 8
  %4 = alloca double, align 8
  store double %1, ptr %3, align 8
  store double %0, ptr %4, align 8
  %5 = load double, ptr %4, align 8
  %6 = load double, ptr %3, align 8
  %7 = fdiv double %5, %6
  ret double %7
}

; Function Attrs: noinline nounwind optnone uwtable
define internal double @madd(double noundef %0, double noundef %1, double noundef %2) #0 {
  %4 = alloca double, align 8
  %5 = alloca double, align 8
  %6 = alloca double, align 8
  %7 = alloca i32, align 4
  store double %2, ptr %4, align 8
  store double %1, ptr %5, align 8
  store double %0, ptr %6, align 8
  %8 = load double, ptr %6, align 8
  %9 = fadd double %8, 1.000000e+00
  %10 = fmul double %9, 1.000000e+100
  %11 = fptosi double %10 to i32
  store i32 %11, ptr %7, align 4
  %12 = load double, ptr %6, align 8
  %13 = load double, ptr %5, align 8
  %14 = fmul double %12, %13
  %15 = load double, ptr %4, align 8
  %16 = fadd double %14, %15
  ret double %16
}

attributes #0 = { noinline nounwind optnone uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nounwind "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { nounwind }

!llvm.dbg.cu = !{!0}
!llvm.module.flags = !{!2, !3, !4, !5, !6}
!llvm.ident = !{!7}

!0 = distinct !DICompileUnit(language: DW_LANG_C11, file: !1, producer: "clang version 21.1.0", isOptimized: false, runtimeVersion: 0, emissionKind: NoDebug, splitDebugInlining: false, nameTableKind: None)
!1 = !DIFile(filename: "G:\\Hackathon-stage2-artifacts\\project19\\20261014-development\\acceptance\\s34-local-ctest-helpers\\cholesky-unused-integer-local.c", directory: "F:\\Hackathon\\projects\\19-dynamic-graph")
!2 = !{i32 2, !"Debug Info Version", i32 3}
!3 = !{i32 1, !"wchar_size", i32 2}
!4 = !{i32 8, !"PIC Level", i32 2}
!5 = !{i32 7, !"uwtable", i32 2}
!6 = !{i32 1, !"MaxTLSAlign", i32 65536}
!7 = !{!"clang version 21.1.0"}
!8 = distinct !{!8, !9}
!9 = !{!"llvm.loop.mustprogress"}
!10 = distinct !{!10, !9}
!11 = distinct !{!11, !9}
