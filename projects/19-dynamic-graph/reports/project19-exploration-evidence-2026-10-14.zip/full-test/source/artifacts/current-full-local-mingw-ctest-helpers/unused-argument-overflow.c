static double h(int ignored,double x){return x;}
int transform(const double*a,double*l,int n){l[0]=h((int)(a[0]*1e100),a[0]);return 0;}