; ModuleID = 'G:\Hackathon-stage2-artifacts\project19\20261014-development\acceptance\s34-local-ctest-integer-selectors\double-argument-conversion.c'
source_filename = "G:\\Hackathon-stage2-artifacts\\project19\\20261014-development\\acceptance\\s34-local-ctest-integer-selectors\\double-argument-conversion.c"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-windows-msvc19.44.35228"

; Function Attrs: noinline nounwind optnone uwtable
define dso_local i32 @cholesky_blocked(ptr noundef %0, ptr noundef %1, i32 noundef %2, i32 noundef %3) #0 {
  %5 = alloca i32, align 4
  %6 = alloca i32, align 4
  %7 = alloca ptr, align 8
  %8 = alloca ptr, align 8
  %9 = alloca i32, align 4
  %10 = alloca i32, align 4
  %11 = alloca i32, align 4
  %12 = alloca i32, align 4
  %13 = alloca i32, align 4
  %14 = alloca i32, align 4
  %15 = alloca i32, align 4
  %16 = alloca i32, align 4
  %17 = alloca i32, align 4
  store i32 %3, ptr %5, align 4
  store i32 %2, ptr %6, align 4
  store ptr %1, ptr %7, align 8
  store ptr %0, ptr %8, align 8
  store i32 0, ptr %9, align 4
  br label %18

18:                                               ; preds = %197, %4
  %19 = load i32, ptr %9, align 4
  %20 = load i32, ptr %6, align 4
  %21 = icmp slt i32 %19, %20
  br i1 %21, label %22, label %201

22:                                               ; preds = %18
  %23 = load i32, ptr %6, align 4
  %24 = load i32, ptr %9, align 4
  %25 = load i32, ptr %5, align 4
  %26 = add nsw i32 %24, %25
  %27 = sitofp i32 %26 to double
  %28 = fadd double %27, 9.000000e-01
  %29 = fptosi double %28 to i32
  %30 = call i32 @choose(i32 noundef %29, i32 noundef %23)
  store i32 %30, ptr %10, align 4
  %31 = load i32, ptr %9, align 4
  store i32 %31, ptr %11, align 4
  br label %32

32:                                               ; preds = %193, %22
  %33 = load i32, ptr %11, align 4
  %34 = load i32, ptr %10, align 4
  %35 = icmp slt i32 %33, %34
  br i1 %35, label %36, label %196

36:                                               ; preds = %32
  %37 = load ptr, ptr %8, align 8
  %38 = load i32, ptr %11, align 4
  %39 = load i32, ptr %6, align 4
  %40 = mul nsw i32 %38, %39
  %41 = load i32, ptr %11, align 4
  %42 = add nsw i32 %40, %41
  %43 = sext i32 %42 to i64
  %44 = getelementptr inbounds double, ptr %37, i64 %43
  %45 = load double, ptr %44, align 8
  %46 = load ptr, ptr %7, align 8
  %47 = load i32, ptr %11, align 4
  %48 = load i32, ptr %6, align 4
  %49 = mul nsw i32 %47, %48
  %50 = load i32, ptr %11, align 4
  %51 = add nsw i32 %49, %50
  %52 = sext i32 %51 to i64
  %53 = getelementptr inbounds double, ptr %46, i64 %52
  %54 = load double, ptr %53, align 8
  %55 = fsub double %45, %54
  %56 = call double @sqrt(double noundef %55) #2
  %57 = load ptr, ptr %7, align 8
  %58 = load i32, ptr %11, align 4
  %59 = load i32, ptr %6, align 4
  %60 = mul nsw i32 %58, %59
  %61 = load i32, ptr %11, align 4
  %62 = add nsw i32 %60, %61
  %63 = sext i32 %62 to i64
  %64 = getelementptr inbounds double, ptr %57, i64 %63
  store double %56, ptr %64, align 8
  %65 = load i32, ptr %11, align 4
  %66 = add nsw i32 %65, 1
  store i32 %66, ptr %12, align 4
  br label %67

67:                                               ; preds = %188, %36
  %68 = load i32, ptr %12, align 4
  %69 = load i32, ptr %6, align 4
  %70 = icmp slt i32 %68, %69
  br i1 %70, label %71, label %192

71:                                               ; preds = %67
  %72 = load i32, ptr %6, align 4
  %73 = load i32, ptr %12, align 4
  %74 = load i32, ptr %5, align 4
  %75 = add nsw i32 %73, %74
  %76 = call i32 @choose(i32 noundef %75, i32 noundef %72)
  store i32 %76, ptr %13, align 4
  %77 = load i32, ptr %12, align 4
  store i32 %77, ptr %14, align 4
  br label %78

78:                                               ; preds = %184, %71
  %79 = load i32, ptr %14, align 4
  %80 = load i32, ptr %13, align 4
  %81 = icmp slt i32 %79, %80
  br i1 %81, label %82, label %187

82:                                               ; preds = %78
  %83 = load ptr, ptr %7, align 8
  %84 = load i32, ptr %11, align 4
  %85 = load i32, ptr %6, align 4
  %86 = mul nsw i32 %84, %85
  %87 = load i32, ptr %11, align 4
  %88 = add nsw i32 %86, %87
  %89 = sext i32 %88 to i64
  %90 = getelementptr inbounds double, ptr %83, i64 %89
  %91 = load double, ptr %90, align 8
  %92 = load ptr, ptr %8, align 8
  %93 = load i32, ptr %14, align 4
  %94 = load i32, ptr %6, align 4
  %95 = mul nsw i32 %93, %94
  %96 = load i32, ptr %11, align 4
  %97 = add nsw i32 %95, %96
  %98 = sext i32 %97 to i64
  %99 = getelementptr inbounds double, ptr %92, i64 %98
  %100 = load double, ptr %99, align 8
  %101 = load ptr, ptr %7, align 8
  %102 = load i32, ptr %14, align 4
  %103 = load i32, ptr %6, align 4
  %104 = mul nsw i32 %102, %103
  %105 = load i32, ptr %11, align 4
  %106 = add nsw i32 %104, %105
  %107 = sext i32 %106 to i64
  %108 = getelementptr inbounds double, ptr %101, i64 %107
  %109 = load double, ptr %108, align 8
  %110 = fsub double %100, %109
  %111 = call double @quotient(double noundef %110, double noundef %91)
  %112 = load ptr, ptr %7, align 8
  %113 = load i32, ptr %14, align 4
  %114 = load i32, ptr %6, align 4
  %115 = mul nsw i32 %113, %114
  %116 = load i32, ptr %11, align 4
  %117 = add nsw i32 %115, %116
  %118 = sext i32 %117 to i64
  %119 = getelementptr inbounds double, ptr %112, i64 %118
  store double %111, ptr %119, align 8
  %120 = load i32, ptr %11, align 4
  %121 = add nsw i32 %120, 1
  store i32 %121, ptr %15, align 4
  br label %122

122:                                              ; preds = %179, %82
  %123 = load i32, ptr %15, align 4
  %124 = load i32, ptr %14, align 4
  %125 = icmp sle i32 %123, %124
  br i1 %125, label %126, label %183

126:                                              ; preds = %122
  %127 = load i32, ptr %14, align 4
  %128 = add nsw i32 %127, 1
  %129 = load i32, ptr %15, align 4
  %130 = load i32, ptr %5, align 4
  %131 = add nsw i32 %129, %130
  %132 = call i32 @choose(i32 noundef %131, i32 noundef %128)
  store i32 %132, ptr %16, align 4
  %133 = load i32, ptr %15, align 4
  store i32 %133, ptr %17, align 4
  br label %134

134:                                              ; preds = %175, %126
  %135 = load i32, ptr %17, align 4
  %136 = load i32, ptr %16, align 4
  %137 = icmp slt i32 %135, %136
  br i1 %137, label %138, label %178

138:                                              ; preds = %134
  %139 = load ptr, ptr %7, align 8
  %140 = load i32, ptr %14, align 4
  %141 = load i32, ptr %6, align 4
  %142 = mul nsw i32 %140, %141
  %143 = load i32, ptr %17, align 4
  %144 = add nsw i32 %142, %143
  %145 = sext i32 %144 to i64
  %146 = getelementptr inbounds double, ptr %139, i64 %145
  %147 = load double, ptr %146, align 8
  %148 = load ptr, ptr %7, align 8
  %149 = load i32, ptr %17, align 4
  %150 = load i32, ptr %6, align 4
  %151 = mul nsw i32 %149, %150
  %152 = load i32, ptr %11, align 4
  %153 = add nsw i32 %151, %152
  %154 = sext i32 %153 to i64
  %155 = getelementptr inbounds double, ptr %148, i64 %154
  %156 = load double, ptr %155, align 8
  %157 = load ptr, ptr %7, align 8
  %158 = load i32, ptr %14, align 4
  %159 = load i32, ptr %6, align 4
  %160 = mul nsw i32 %158, %159
  %161 = load i32, ptr %11, align 4
  %162 = add nsw i32 %160, %161
  %163 = sext i32 %162 to i64
  %164 = getelementptr inbounds double, ptr %157, i64 %163
  %165 = load double, ptr %164, align 8
  %166 = call double @multiply_add(double noundef %165, double noundef %156, double noundef %147)
  %167 = load ptr, ptr %7, align 8
  %168 = load i32, ptr %14, align 4
  %169 = load i32, ptr %6, align 4
  %170 = mul nsw i32 %168, %169
  %171 = load i32, ptr %17, align 4
  %172 = add nsw i32 %170, %171
  %173 = sext i32 %172 to i64
  %174 = getelementptr inbounds double, ptr %167, i64 %173
  store double %166, ptr %174, align 8
  br label %175

175:                                              ; preds = %138
  %176 = load i32, ptr %17, align 4
  %177 = add nsw i32 %176, 1
  store i32 %177, ptr %17, align 4
  br label %134, !llvm.loop !8

178:                                              ; preds = %134
  br label %179

179:                                              ; preds = %178
  %180 = load i32, ptr %5, align 4
  %181 = load i32, ptr %15, align 4
  %182 = add nsw i32 %181, %180
  store i32 %182, ptr %15, align 4
  br label %122, !llvm.loop !10

183:                                              ; preds = %122
  br label %184

184:                                              ; preds = %183
  %185 = load i32, ptr %14, align 4
  %186 = add nsw i32 %185, 1
  store i32 %186, ptr %14, align 4
  br label %78, !llvm.loop !11

187:                                              ; preds = %78
  br label %188

188:                                              ; preds = %187
  %189 = load i32, ptr %5, align 4
  %190 = load i32, ptr %12, align 4
  %191 = add nsw i32 %190, %189
  store i32 %191, ptr %12, align 4
  br label %67, !llvm.loop !12

192:                                              ; preds = %67
  br label %193

193:                                              ; preds = %192
  %194 = load i32, ptr %11, align 4
  %195 = add nsw i32 %194, 1
  store i32 %195, ptr %11, align 4
  br label %32, !llvm.loop !13

196:                                              ; preds = %32
  br label %197

197:                                              ; preds = %196
  %198 = load i32, ptr %5, align 4
  %199 = load i32, ptr %9, align 4
  %200 = add nsw i32 %199, %198
  store i32 %200, ptr %9, align 4
  br label %18, !llvm.loop !14

201:                                              ; preds = %18
  ret i32 0
}

; Function Attrs: noinline nounwind optnone uwtable
define internal i32 @choose(i32 noundef %0, i32 noundef %1) #0 {
  %3 = alloca i32, align 4
  %4 = alloca i32, align 4
  store i32 %1, ptr %3, align 4
  store i32 %0, ptr %4, align 4
  %5 = load i32, ptr %4, align 4
  %6 = load i32, ptr %3, align 4
  %7 = icmp slt i32 %5, %6
  br i1 %7, label %8, label %10

8:                                                ; preds = %2
  %9 = load i32, ptr %4, align 4
  br label %12

10:                                               ; preds = %2
  %11 = load i32, ptr %3, align 4
  br label %12

12:                                               ; preds = %10, %8
  %13 = phi i32 [ %9, %8 ], [ %11, %10 ]
  ret i32 %13
}

; Function Attrs: nounwind
declare dso_local double @sqrt(double noundef) #1

; Function Attrs: noinline nounwind optnone uwtable
define internal double @quotient(double noundef %0, double noundef %1) #0 {
  %3 = alloca double, align 8
  %4 = alloca double, align 8
  store double %1, ptr %3, align 8
  store double %0, ptr %4, align 8
  %5 = load double, ptr %4, align 8
  %6 = load double, ptr %3, align 8
  %7 = fdiv double %5, %6
  ret double %7
}

; Function Attrs: noinline nounwind optnone uwtable
define internal double @multiply_add(double noundef %0, double noundef %1, double noundef %2) #0 {
  %4 = alloca double, align 8
  %5 = alloca double, align 8
  %6 = alloca double, align 8
  store double %2, ptr %4, align 8
  store double %1, ptr %5, align 8
  store double %0, ptr %6, align 8
  %7 = load double, ptr %6, align 8
  %8 = load double, ptr %5, align 8
  %9 = fmul double %7, %8
  %10 = load double, ptr %4, align 8
  %11 = fadd double %9, %10
  ret double %11
}

attributes #0 = { noinline nounwind optnone uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nounwind "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { nounwind }

!llvm.dbg.cu = !{!0}
!llvm.module.flags = !{!2, !3, !4, !5, !6}
!llvm.ident = !{!7}

!0 = distinct !DICompileUnit(language: DW_LANG_C11, file: !1, producer: "clang version 21.1.0", isOptimized: false, runtimeVersion: 0, emissionKind: NoDebug, splitDebugInlining: false, nameTableKind: None)
!1 = !DIFile(filename: "G:\\Hackathon-stage2-artifacts\\project19\\20261014-development\\acceptance\\s34-local-ctest-integer-selectors\\double-argument-conversion.c", directory: "F:\\Hackathon\\projects\\19-dynamic-graph")
!2 = !{i32 2, !"Debug Info Version", i32 3}
!3 = !{i32 1, !"wchar_size", i32 2}
!4 = !{i32 8, !"PIC Level", i32 2}
!5 = !{i32 7, !"uwtable", i32 2}
!6 = !{i32 1, !"MaxTLSAlign", i32 65536}
!7 = !{!"clang version 21.1.0"}
!8 = distinct !{!8, !9}
!9 = !{!"llvm.loop.mustprogress"}
!10 = distinct !{!10, !9}
!11 = distinct !{!11, !9}
!12 = distinct !{!12, !9}
!13 = distinct !{!13, !9}
!14 = distinct !{!14, !9}
