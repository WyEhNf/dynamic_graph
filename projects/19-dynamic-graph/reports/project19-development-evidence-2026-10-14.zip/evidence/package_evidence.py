from pathlib import Path
import hashlib,json,zipfile
R=Path(__file__).resolve().parent;P=Path('F:/Hackathon/projects/19-dynamic-graph')
sha=lambda data:hashlib.sha256(data).hexdigest()
files={}
excluded={'build','build-memory','rollback','default-audit'}
suffixes={'.json','.meta','.py','.cpp','.hpp','.c','.ll','.log','.txt','.ps1','.h'}
for path in sorted(R.rglob('*')):
    rel=path.relative_to(R)
    if not path.is_file() or rel.parts[0] in excluded or path.suffix not in suffixes:continue
    files['evidence/'+rel.as_posix()]=path
# Default audit: preserve its complete report; regenerations are redundant files.
files['evidence/default-audit/report.json']=R/'default-audit/report.json'
for name in ['README.md','docs/metadata.md','docs/task19-requirements-2026-10-14.md','docs/development-2026-10-14.md','research/task19-requirements-2026-10-14.png']:
    files['project/'+name]=P/name
manifest={name:dict(bytes=path.stat().st_size,sha256=sha(path.read_bytes())) for name,path in files.items()}
archive=R/'project19-development-evidence-2026-10-14.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for name,path in files.items():z.write(path,name)
    z.writestr('EVIDENCE-MANIFEST.json',json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for name,info in manifest.items():
        data=z.read(name);assert sha(data)==info['sha256'] and len(data)==info['bytes']
release=json.loads((R/'release-manifest.json').read_text());assert release['status']=='installed_validated'
summary=dict(status='validated_installed',stage='S34',baseline_git_commit='09868ad',
    release=release,ctest=dict(local_passed=18,memory_passed=13,final_packed_contract_followup_each=1),
    primary_cholesky_full_file_comparisons=576,maximum_n10000_full_file_comparisons=4,
    installed_smoke_full_file_comparisons=2,minimum_selector_full_file_comparisons=24,
    minimum_selector_source_classification='Three Cholesky and three general VM controls; do not count all as Cholesky',
    default_metadata_byte_audit=json.loads((R/'default-audit/report.json').read_text()),
    size=json.loads((R/'metadata-screen/size-report.json').read_text()),
    reader=json.loads((R/'reader-screen/report.json').read_text()),
    geometry=json.loads((R/'tile128-parallel/report.json').read_text()),
    requirements_screenshot_sha256=sha((P/'research/task19-requirements-2026-10-14.png').read_bytes()),
    evidence_archive=dict(file=archive.name,bytes=archive.stat().st_size,sha256=sha(archive.read_bytes()),
                          included_files=len(manifest),crc_and_all_sha_verified=True),
    limitations=['User-provided official page screenshot, no official test package or complete official blocked source',
      'Local div/madd and zero-initialization/endian contract explicitly documented',
      'Windows/x86 measurements; Kunpeng/ARM64 validation pending',
      'Loader hot repetition includes I/O; not matrix compute or official score improvement',
      'Tile128 promotion gate failed; current default preserved',
      'Historical first geometry configuration invalid (1 worker), retained but excluded',
      'S33 exploration PDF remains historical snapshot; development document is S34 supplement'])
target=P/'reports/project19-development-validation-2026-10-14.json'
target.write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
destination=P/'reports'/archive.name;destination.write_bytes(archive.read_bytes())
assert sha(destination.read_bytes())==summary['evidence_archive']['sha256']
print(json.dumps(summary['evidence_archive'],indent=2))
