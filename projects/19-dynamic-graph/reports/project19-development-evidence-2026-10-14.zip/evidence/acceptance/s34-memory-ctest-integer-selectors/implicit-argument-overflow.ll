; ModuleID = 'G:\Hackathon-stage2-artifacts\project19\20261014-development\acceptance\s34-memory-ctest-integer-selectors\implicit-argument-overflow.c'
source_filename = "G:\\Hackathon-stage2-artifacts\\project19\\20261014-development\\acceptance\\s34-memory-ctest-integer-selectors\\implicit-argument-overflow.c"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-windows-msvc19.44.35228"

; Function Attrs: noinline nounwind optnone uwtable
define dso_local i32 @cholesky_blocked(ptr noundef %0, ptr noundef %1, i32 noundef %2, i32 noundef %3) #0 {
  %5 = alloca i32, align 4
  %6 = alloca i32, align 4
  %7 = alloca ptr, align 8
  %8 = alloca ptr, align 8
  %9 = alloca i32, align 4
  %10 = alloca i32, align 4
  %11 = alloca i32, align 4
  %12 = alloca i32, align 4
  %13 = alloca i32, align 4
  %14 = alloca i32, align 4
  %15 = alloca i32, align 4
  %16 = alloca i32, align 4
  %17 = alloca i32, align 4
  store i32 %3, ptr %5, align 4
  store i32 %2, ptr %6, align 4
  store ptr %1, ptr %7, align 8
  store ptr %0, ptr %8, align 8
  store i32 0, ptr %9, align 4
  br label %18

18:                                               ; preds = %196, %4
  %19 = load i32, ptr %9, align 4
  %20 = load i32, ptr %6, align 4
  %21 = icmp slt i32 %19, %20
  br i1 %21, label %22, label %200

22:                                               ; preds = %18
  %23 = load i32, ptr %6, align 4
  %24 = load ptr, ptr %8, align 8
  %25 = getelementptr inbounds double, ptr %24, i64 0
  %26 = load double, ptr %25, align 8
  %27 = fmul double %26, 1.000000e+100
  %28 = fptosi double %27 to i32
  %29 = call i32 @choose(i32 noundef %28, i32 noundef %23)
  store i32 %29, ptr %10, align 4
  %30 = load i32, ptr %9, align 4
  store i32 %30, ptr %11, align 4
  br label %31

31:                                               ; preds = %192, %22
  %32 = load i32, ptr %11, align 4
  %33 = load i32, ptr %10, align 4
  %34 = icmp slt i32 %32, %33
  br i1 %34, label %35, label %195

35:                                               ; preds = %31
  %36 = load ptr, ptr %8, align 8
  %37 = load i32, ptr %11, align 4
  %38 = load i32, ptr %6, align 4
  %39 = mul nsw i32 %37, %38
  %40 = load i32, ptr %11, align 4
  %41 = add nsw i32 %39, %40
  %42 = sext i32 %41 to i64
  %43 = getelementptr inbounds double, ptr %36, i64 %42
  %44 = load double, ptr %43, align 8
  %45 = load ptr, ptr %7, align 8
  %46 = load i32, ptr %11, align 4
  %47 = load i32, ptr %6, align 4
  %48 = mul nsw i32 %46, %47
  %49 = load i32, ptr %11, align 4
  %50 = add nsw i32 %48, %49
  %51 = sext i32 %50 to i64
  %52 = getelementptr inbounds double, ptr %45, i64 %51
  %53 = load double, ptr %52, align 8
  %54 = fsub double %44, %53
  %55 = call double @sqrt(double noundef %54) #2
  %56 = load ptr, ptr %7, align 8
  %57 = load i32, ptr %11, align 4
  %58 = load i32, ptr %6, align 4
  %59 = mul nsw i32 %57, %58
  %60 = load i32, ptr %11, align 4
  %61 = add nsw i32 %59, %60
  %62 = sext i32 %61 to i64
  %63 = getelementptr inbounds double, ptr %56, i64 %62
  store double %55, ptr %63, align 8
  %64 = load i32, ptr %11, align 4
  %65 = add nsw i32 %64, 1
  store i32 %65, ptr %12, align 4
  br label %66

66:                                               ; preds = %187, %35
  %67 = load i32, ptr %12, align 4
  %68 = load i32, ptr %6, align 4
  %69 = icmp slt i32 %67, %68
  br i1 %69, label %70, label %191

70:                                               ; preds = %66
  %71 = load i32, ptr %6, align 4
  %72 = load i32, ptr %12, align 4
  %73 = load i32, ptr %5, align 4
  %74 = add nsw i32 %72, %73
  %75 = call i32 @choose(i32 noundef %74, i32 noundef %71)
  store i32 %75, ptr %13, align 4
  %76 = load i32, ptr %12, align 4
  store i32 %76, ptr %14, align 4
  br label %77

77:                                               ; preds = %183, %70
  %78 = load i32, ptr %14, align 4
  %79 = load i32, ptr %13, align 4
  %80 = icmp slt i32 %78, %79
  br i1 %80, label %81, label %186

81:                                               ; preds = %77
  %82 = load ptr, ptr %7, align 8
  %83 = load i32, ptr %11, align 4
  %84 = load i32, ptr %6, align 4
  %85 = mul nsw i32 %83, %84
  %86 = load i32, ptr %11, align 4
  %87 = add nsw i32 %85, %86
  %88 = sext i32 %87 to i64
  %89 = getelementptr inbounds double, ptr %82, i64 %88
  %90 = load double, ptr %89, align 8
  %91 = load ptr, ptr %8, align 8
  %92 = load i32, ptr %14, align 4
  %93 = load i32, ptr %6, align 4
  %94 = mul nsw i32 %92, %93
  %95 = load i32, ptr %11, align 4
  %96 = add nsw i32 %94, %95
  %97 = sext i32 %96 to i64
  %98 = getelementptr inbounds double, ptr %91, i64 %97
  %99 = load double, ptr %98, align 8
  %100 = load ptr, ptr %7, align 8
  %101 = load i32, ptr %14, align 4
  %102 = load i32, ptr %6, align 4
  %103 = mul nsw i32 %101, %102
  %104 = load i32, ptr %11, align 4
  %105 = add nsw i32 %103, %104
  %106 = sext i32 %105 to i64
  %107 = getelementptr inbounds double, ptr %100, i64 %106
  %108 = load double, ptr %107, align 8
  %109 = fsub double %99, %108
  %110 = call double @quotient(double noundef %109, double noundef %90)
  %111 = load ptr, ptr %7, align 8
  %112 = load i32, ptr %14, align 4
  %113 = load i32, ptr %6, align 4
  %114 = mul nsw i32 %112, %113
  %115 = load i32, ptr %11, align 4
  %116 = add nsw i32 %114, %115
  %117 = sext i32 %116 to i64
  %118 = getelementptr inbounds double, ptr %111, i64 %117
  store double %110, ptr %118, align 8
  %119 = load i32, ptr %11, align 4
  %120 = add nsw i32 %119, 1
  store i32 %120, ptr %15, align 4
  br label %121

121:                                              ; preds = %178, %81
  %122 = load i32, ptr %15, align 4
  %123 = load i32, ptr %14, align 4
  %124 = icmp sle i32 %122, %123
  br i1 %124, label %125, label %182

125:                                              ; preds = %121
  %126 = load i32, ptr %14, align 4
  %127 = add nsw i32 %126, 1
  %128 = load i32, ptr %15, align 4
  %129 = load i32, ptr %5, align 4
  %130 = add nsw i32 %128, %129
  %131 = call i32 @choose(i32 noundef %130, i32 noundef %127)
  store i32 %131, ptr %16, align 4
  %132 = load i32, ptr %15, align 4
  store i32 %132, ptr %17, align 4
  br label %133

133:                                              ; preds = %174, %125
  %134 = load i32, ptr %17, align 4
  %135 = load i32, ptr %16, align 4
  %136 = icmp slt i32 %134, %135
  br i1 %136, label %137, label %177

137:                                              ; preds = %133
  %138 = load ptr, ptr %7, align 8
  %139 = load i32, ptr %14, align 4
  %140 = load i32, ptr %6, align 4
  %141 = mul nsw i32 %139, %140
  %142 = load i32, ptr %17, align 4
  %143 = add nsw i32 %141, %142
  %144 = sext i32 %143 to i64
  %145 = getelementptr inbounds double, ptr %138, i64 %144
  %146 = load double, ptr %145, align 8
  %147 = load ptr, ptr %7, align 8
  %148 = load i32, ptr %17, align 4
  %149 = load i32, ptr %6, align 4
  %150 = mul nsw i32 %148, %149
  %151 = load i32, ptr %11, align 4
  %152 = add nsw i32 %150, %151
  %153 = sext i32 %152 to i64
  %154 = getelementptr inbounds double, ptr %147, i64 %153
  %155 = load double, ptr %154, align 8
  %156 = load ptr, ptr %7, align 8
  %157 = load i32, ptr %14, align 4
  %158 = load i32, ptr %6, align 4
  %159 = mul nsw i32 %157, %158
  %160 = load i32, ptr %11, align 4
  %161 = add nsw i32 %159, %160
  %162 = sext i32 %161 to i64
  %163 = getelementptr inbounds double, ptr %156, i64 %162
  %164 = load double, ptr %163, align 8
  %165 = call double @multiply_add(double noundef %164, double noundef %155, double noundef %146)
  %166 = load ptr, ptr %7, align 8
  %167 = load i32, ptr %14, align 4
  %168 = load i32, ptr %6, align 4
  %169 = mul nsw i32 %167, %168
  %170 = load i32, ptr %17, align 4
  %171 = add nsw i32 %169, %170
  %172 = sext i32 %171 to i64
  %173 = getelementptr inbounds double, ptr %166, i64 %172
  store double %165, ptr %173, align 8
  br label %174

174:                                              ; preds = %137
  %175 = load i32, ptr %17, align 4
  %176 = add nsw i32 %175, 1
  store i32 %176, ptr %17, align 4
  br label %133, !llvm.loop !8

177:                                              ; preds = %133
  br label %178

178:                                              ; preds = %177
  %179 = load i32, ptr %5, align 4
  %180 = load i32, ptr %15, align 4
  %181 = add nsw i32 %180, %179
  store i32 %181, ptr %15, align 4
  br label %121, !llvm.loop !10

182:                                              ; preds = %121
  br label %183

183:                                              ; preds = %182
  %184 = load i32, ptr %14, align 4
  %185 = add nsw i32 %184, 1
  store i32 %185, ptr %14, align 4
  br label %77, !llvm.loop !11

186:                                              ; preds = %77
  br label %187

187:                                              ; preds = %186
  %188 = load i32, ptr %5, align 4
  %189 = load i32, ptr %12, align 4
  %190 = add nsw i32 %189, %188
  store i32 %190, ptr %12, align 4
  br label %66, !llvm.loop !12

191:                                              ; preds = %66
  br label %192

192:                                              ; preds = %191
  %193 = load i32, ptr %11, align 4
  %194 = add nsw i32 %193, 1
  store i32 %194, ptr %11, align 4
  br label %31, !llvm.loop !13

195:                                              ; preds = %31
  br label %196

196:                                              ; preds = %195
  %197 = load i32, ptr %5, align 4
  %198 = load i32, ptr %9, align 4
  %199 = add nsw i32 %198, %197
  store i32 %199, ptr %9, align 4
  br label %18, !llvm.loop !14

200:                                              ; preds = %18
  ret i32 0
}

; Function Attrs: noinline nounwind optnone uwtable
define internal i32 @choose(i32 noundef %0, i32 noundef %1) #0 {
  %3 = alloca i32, align 4
  %4 = alloca i32, align 4
  store i32 %1, ptr %3, align 4
  store i32 %0, ptr %4, align 4
  %5 = load i32, ptr %4, align 4
  %6 = load i32, ptr %3, align 4
  %7 = icmp slt i32 %5, %6
  br i1 %7, label %8, label %10

8:                                                ; preds = %2
  %9 = load i32, ptr %4, align 4
  br label %12

10:                                               ; preds = %2
  %11 = load i32, ptr %3, align 4
  br label %12

12:                                               ; preds = %10, %8
  %13 = phi i32 [ %9, %8 ], [ %11, %10 ]
  ret i32 %13
}

; Function Attrs: nounwind
declare dso_local double @sqrt(double noundef) #1

; Function Attrs: noinline nounwind optnone uwtable
define internal double @quotient(double noundef %0, double noundef %1) #0 {
  %3 = alloca double, align 8
  %4 = alloca double, align 8
  store double %1, ptr %3, align 8
  store double %0, ptr %4, align 8
  %5 = load double, ptr %4, align 8
  %6 = load double, ptr %3, align 8
  %7 = fdiv double %5, %6
  ret double %7
}

; Function Attrs: noinline nounwind optnone uwtable
define internal double @multiply_add(double noundef %0, double noundef %1, double noundef %2) #0 {
  %4 = alloca double, align 8
  %5 = alloca double, align 8
  %6 = alloca double, align 8
  store double %2, ptr %4, align 8
  store double %1, ptr %5, align 8
  store double %0, ptr %6, align 8
  %7 = load double, ptr %6, align 8
  %8 = load double, ptr %5, align 8
  %9 = fmul double %7, %8
  %10 = load double, ptr %4, align 8
  %11 = fadd double %9, %10
  ret double %11
}

attributes #0 = { noinline nounwind optnone uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nounwind "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { nounwind }

!llvm.dbg.cu = !{!0}
!llvm.module.flags = !{!2, !3, !4, !5, !6}
!llvm.ident = !{!7}

!0 = distinct !DICompileUnit(language: DW_LANG_C11, file: !1, producer: "clang version 21.1.0", isOptimized: false, runtimeVersion: 0, emissionKind: NoDebug, splitDebugInlining: false, nameTableKind: None)
!1 = !DIFile(filename: "G:\\Hackathon-stage2-artifacts\\project19\\20261014-development\\acceptance\\s34-memory-ctest-integer-selectors\\implicit-argument-overflow.c", directory: "F:\\Hackathon\\projects\\19-dynamic-graph")
!2 = !{i32 2, !"Debug Info Version", i32 3}
!3 = !{i32 1, !"wchar_size", i32 2}
!4 = !{i32 8, !"PIC Level", i32 2}
!5 = !{i32 7, !"uwtable", i32 2}
!6 = !{i32 1, !"MaxTLSAlign", i32 65536}
!7 = !{!"clang version 21.1.0"}
!8 = distinct !{!8, !9}
!9 = !{!"llvm.loop.mustprogress"}
!10 = distinct !{!10, !9}
!11 = distinct !{!11, !9}
!12 = distinct !{!12, !9}
!13 = distinct !{!13, !9}
!14 = distinct !{!14, !9}
