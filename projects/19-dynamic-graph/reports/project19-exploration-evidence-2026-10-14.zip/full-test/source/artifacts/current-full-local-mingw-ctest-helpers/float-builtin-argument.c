extern double fabs(float);
int transform(const double*a,double*l,int n){l[0]=fabs(a[0]);return 0;}