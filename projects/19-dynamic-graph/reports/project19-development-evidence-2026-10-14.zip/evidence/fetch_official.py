from pathlib import Path
import hashlib,json,re,urllib.request,urllib.parse,datetime
ROOT=Path(__file__).resolve().parent/'official';ROOT.mkdir(exist_ok=True)
def fetch(url,name):
 req=urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0'})
 with urllib.request.urlopen(req,timeout=30) as r:b=r.read()
 (ROOT/name).write_bytes(b);print(json.dumps(dict(url=url,name=name,bytes=len(b),sha256=hashlib.sha256(b).hexdigest())),flush=True);return b.decode('utf-8')
html=fetch('https://www.chaspark.com/','index.html')
urls=re.findall(r'<script[^>]+src=["\x27]([^"\x27]+)',html)
for u in urls:
 if 'assets/index-' in u:fetch(urllib.parse.urljoin('https://www.chaspark.com/',u),'framework-index.js')
