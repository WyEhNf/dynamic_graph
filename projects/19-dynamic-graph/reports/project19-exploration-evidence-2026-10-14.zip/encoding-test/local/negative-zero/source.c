int zeros(const double *a,double *l,int n) {
 for(int i=0;i<n*n;i=i+1) l[i]=-0.0;
 return 0;
}
