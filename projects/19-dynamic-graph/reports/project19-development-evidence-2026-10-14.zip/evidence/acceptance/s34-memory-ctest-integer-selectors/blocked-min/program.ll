; ModuleID = 'G:\Hackathon-stage2-artifacts\project19\20261014-development\acceptance\s34-memory-ctest-integer-selectors\blocked-min.c'
source_filename = "G:\\Hackathon-stage2-artifacts\\project19\\20261014-development\\acceptance\\s34-memory-ctest-integer-selectors\\blocked-min.c"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-windows-msvc19.44.35228"

; Function Attrs: noinline nounwind optnone uwtable
define dso_local i32 @cholesky_blocked(ptr noundef %0, ptr noundef %1, i32 noundef %2, i32 noundef %3) #0 {
  %5 = alloca i32, align 4
  %6 = alloca i32, align 4
  %7 = alloca ptr, align 8
  %8 = alloca ptr, align 8
  %9 = alloca i32, align 4
  %10 = alloca i32, align 4
  %11 = alloca i32, align 4
  %12 = alloca i32, align 4
  %13 = alloca i32, align 4
  %14 = alloca i32, align 4
  %15 = alloca i32, align 4
  %16 = alloca i32, align 4
  %17 = alloca i32, align 4
  store i32 %3, ptr %5, align 4
  store i32 %2, ptr %6, align 4
  store ptr %1, ptr %7, align 8
  store ptr %0, ptr %8, align 8
  store i32 0, ptr %9, align 4
  br label %18

18:                                               ; preds = %194, %4
  %19 = load i32, ptr %9, align 4
  %20 = load i32, ptr %6, align 4
  %21 = icmp slt i32 %19, %20
  br i1 %21, label %22, label %198

22:                                               ; preds = %18
  %23 = load i32, ptr %6, align 4
  %24 = load i32, ptr %9, align 4
  %25 = load i32, ptr %5, align 4
  %26 = add nsw i32 %24, %25
  %27 = call i32 @choose(i32 noundef %26, i32 noundef %23)
  store i32 %27, ptr %10, align 4
  %28 = load i32, ptr %9, align 4
  store i32 %28, ptr %11, align 4
  br label %29

29:                                               ; preds = %190, %22
  %30 = load i32, ptr %11, align 4
  %31 = load i32, ptr %10, align 4
  %32 = icmp slt i32 %30, %31
  br i1 %32, label %33, label %193

33:                                               ; preds = %29
  %34 = load ptr, ptr %8, align 8
  %35 = load i32, ptr %11, align 4
  %36 = load i32, ptr %6, align 4
  %37 = mul nsw i32 %35, %36
  %38 = load i32, ptr %11, align 4
  %39 = add nsw i32 %37, %38
  %40 = sext i32 %39 to i64
  %41 = getelementptr inbounds double, ptr %34, i64 %40
  %42 = load double, ptr %41, align 8
  %43 = load ptr, ptr %7, align 8
  %44 = load i32, ptr %11, align 4
  %45 = load i32, ptr %6, align 4
  %46 = mul nsw i32 %44, %45
  %47 = load i32, ptr %11, align 4
  %48 = add nsw i32 %46, %47
  %49 = sext i32 %48 to i64
  %50 = getelementptr inbounds double, ptr %43, i64 %49
  %51 = load double, ptr %50, align 8
  %52 = fsub double %42, %51
  %53 = call double @sqrt(double noundef %52) #2
  %54 = load ptr, ptr %7, align 8
  %55 = load i32, ptr %11, align 4
  %56 = load i32, ptr %6, align 4
  %57 = mul nsw i32 %55, %56
  %58 = load i32, ptr %11, align 4
  %59 = add nsw i32 %57, %58
  %60 = sext i32 %59 to i64
  %61 = getelementptr inbounds double, ptr %54, i64 %60
  store double %53, ptr %61, align 8
  %62 = load i32, ptr %11, align 4
  %63 = add nsw i32 %62, 1
  store i32 %63, ptr %12, align 4
  br label %64

64:                                               ; preds = %185, %33
  %65 = load i32, ptr %12, align 4
  %66 = load i32, ptr %6, align 4
  %67 = icmp slt i32 %65, %66
  br i1 %67, label %68, label %189

68:                                               ; preds = %64
  %69 = load i32, ptr %6, align 4
  %70 = load i32, ptr %12, align 4
  %71 = load i32, ptr %5, align 4
  %72 = add nsw i32 %70, %71
  %73 = call i32 @choose(i32 noundef %72, i32 noundef %69)
  store i32 %73, ptr %13, align 4
  %74 = load i32, ptr %12, align 4
  store i32 %74, ptr %14, align 4
  br label %75

75:                                               ; preds = %181, %68
  %76 = load i32, ptr %14, align 4
  %77 = load i32, ptr %13, align 4
  %78 = icmp slt i32 %76, %77
  br i1 %78, label %79, label %184

79:                                               ; preds = %75
  %80 = load ptr, ptr %7, align 8
  %81 = load i32, ptr %11, align 4
  %82 = load i32, ptr %6, align 4
  %83 = mul nsw i32 %81, %82
  %84 = load i32, ptr %11, align 4
  %85 = add nsw i32 %83, %84
  %86 = sext i32 %85 to i64
  %87 = getelementptr inbounds double, ptr %80, i64 %86
  %88 = load double, ptr %87, align 8
  %89 = load ptr, ptr %8, align 8
  %90 = load i32, ptr %14, align 4
  %91 = load i32, ptr %6, align 4
  %92 = mul nsw i32 %90, %91
  %93 = load i32, ptr %11, align 4
  %94 = add nsw i32 %92, %93
  %95 = sext i32 %94 to i64
  %96 = getelementptr inbounds double, ptr %89, i64 %95
  %97 = load double, ptr %96, align 8
  %98 = load ptr, ptr %7, align 8
  %99 = load i32, ptr %14, align 4
  %100 = load i32, ptr %6, align 4
  %101 = mul nsw i32 %99, %100
  %102 = load i32, ptr %11, align 4
  %103 = add nsw i32 %101, %102
  %104 = sext i32 %103 to i64
  %105 = getelementptr inbounds double, ptr %98, i64 %104
  %106 = load double, ptr %105, align 8
  %107 = fsub double %97, %106
  %108 = call double @quotient(double noundef %107, double noundef %88)
  %109 = load ptr, ptr %7, align 8
  %110 = load i32, ptr %14, align 4
  %111 = load i32, ptr %6, align 4
  %112 = mul nsw i32 %110, %111
  %113 = load i32, ptr %11, align 4
  %114 = add nsw i32 %112, %113
  %115 = sext i32 %114 to i64
  %116 = getelementptr inbounds double, ptr %109, i64 %115
  store double %108, ptr %116, align 8
  %117 = load i32, ptr %11, align 4
  %118 = add nsw i32 %117, 1
  store i32 %118, ptr %15, align 4
  br label %119

119:                                              ; preds = %176, %79
  %120 = load i32, ptr %15, align 4
  %121 = load i32, ptr %14, align 4
  %122 = icmp sle i32 %120, %121
  br i1 %122, label %123, label %180

123:                                              ; preds = %119
  %124 = load i32, ptr %14, align 4
  %125 = add nsw i32 %124, 1
  %126 = load i32, ptr %15, align 4
  %127 = load i32, ptr %5, align 4
  %128 = add nsw i32 %126, %127
  %129 = call i32 @choose(i32 noundef %128, i32 noundef %125)
  store i32 %129, ptr %16, align 4
  %130 = load i32, ptr %15, align 4
  store i32 %130, ptr %17, align 4
  br label %131

131:                                              ; preds = %172, %123
  %132 = load i32, ptr %17, align 4
  %133 = load i32, ptr %16, align 4
  %134 = icmp slt i32 %132, %133
  br i1 %134, label %135, label %175

135:                                              ; preds = %131
  %136 = load ptr, ptr %7, align 8
  %137 = load i32, ptr %14, align 4
  %138 = load i32, ptr %6, align 4
  %139 = mul nsw i32 %137, %138
  %140 = load i32, ptr %17, align 4
  %141 = add nsw i32 %139, %140
  %142 = sext i32 %141 to i64
  %143 = getelementptr inbounds double, ptr %136, i64 %142
  %144 = load double, ptr %143, align 8
  %145 = load ptr, ptr %7, align 8
  %146 = load i32, ptr %17, align 4
  %147 = load i32, ptr %6, align 4
  %148 = mul nsw i32 %146, %147
  %149 = load i32, ptr %11, align 4
  %150 = add nsw i32 %148, %149
  %151 = sext i32 %150 to i64
  %152 = getelementptr inbounds double, ptr %145, i64 %151
  %153 = load double, ptr %152, align 8
  %154 = load ptr, ptr %7, align 8
  %155 = load i32, ptr %14, align 4
  %156 = load i32, ptr %6, align 4
  %157 = mul nsw i32 %155, %156
  %158 = load i32, ptr %11, align 4
  %159 = add nsw i32 %157, %158
  %160 = sext i32 %159 to i64
  %161 = getelementptr inbounds double, ptr %154, i64 %160
  %162 = load double, ptr %161, align 8
  %163 = call double @multiply_add(double noundef %162, double noundef %153, double noundef %144)
  %164 = load ptr, ptr %7, align 8
  %165 = load i32, ptr %14, align 4
  %166 = load i32, ptr %6, align 4
  %167 = mul nsw i32 %165, %166
  %168 = load i32, ptr %17, align 4
  %169 = add nsw i32 %167, %168
  %170 = sext i32 %169 to i64
  %171 = getelementptr inbounds double, ptr %164, i64 %170
  store double %163, ptr %171, align 8
  br label %172

172:                                              ; preds = %135
  %173 = load i32, ptr %17, align 4
  %174 = add nsw i32 %173, 1
  store i32 %174, ptr %17, align 4
  br label %131, !llvm.loop !8

175:                                              ; preds = %131
  br label %176

176:                                              ; preds = %175
  %177 = load i32, ptr %5, align 4
  %178 = load i32, ptr %15, align 4
  %179 = add nsw i32 %178, %177
  store i32 %179, ptr %15, align 4
  br label %119, !llvm.loop !10

180:                                              ; preds = %119
  br label %181

181:                                              ; preds = %180
  %182 = load i32, ptr %14, align 4
  %183 = add nsw i32 %182, 1
  store i32 %183, ptr %14, align 4
  br label %75, !llvm.loop !11

184:                                              ; preds = %75
  br label %185

185:                                              ; preds = %184
  %186 = load i32, ptr %5, align 4
  %187 = load i32, ptr %12, align 4
  %188 = add nsw i32 %187, %186
  store i32 %188, ptr %12, align 4
  br label %64, !llvm.loop !12

189:                                              ; preds = %64
  br label %190

190:                                              ; preds = %189
  %191 = load i32, ptr %11, align 4
  %192 = add nsw i32 %191, 1
  store i32 %192, ptr %11, align 4
  br label %29, !llvm.loop !13

193:                                              ; preds = %29
  br label %194

194:                                              ; preds = %193
  %195 = load i32, ptr %5, align 4
  %196 = load i32, ptr %9, align 4
  %197 = add nsw i32 %196, %195
  store i32 %197, ptr %9, align 4
  br label %18, !llvm.loop !14

198:                                              ; preds = %18
  ret i32 0
}

; Function Attrs: noinline nounwind optnone uwtable
define internal i32 @choose(i32 noundef %0, i32 noundef %1) #0 {
  %3 = alloca i32, align 4
  %4 = alloca i32, align 4
  store i32 %1, ptr %3, align 4
  store i32 %0, ptr %4, align 4
  %5 = load i32, ptr %4, align 4
  %6 = load i32, ptr %3, align 4
  %7 = icmp slt i32 %5, %6
  br i1 %7, label %8, label %10

8:                                                ; preds = %2
  %9 = load i32, ptr %4, align 4
  br label %12

10:                                               ; preds = %2
  %11 = load i32, ptr %3, align 4
  br label %12

12:                                               ; preds = %10, %8
  %13 = phi i32 [ %9, %8 ], [ %11, %10 ]
  ret i32 %13
}

; Function Attrs: nounwind
declare dso_local double @sqrt(double noundef) #1

; Function Attrs: noinline nounwind optnone uwtable
define internal double @quotient(double noundef %0, double noundef %1) #0 {
  %3 = alloca double, align 8
  %4 = alloca double, align 8
  store double %1, ptr %3, align 8
  store double %0, ptr %4, align 8
  %5 = load double, ptr %4, align 8
  %6 = load double, ptr %3, align 8
  %7 = fdiv double %5, %6
  ret double %7
}

; Function Attrs: noinline nounwind optnone uwtable
define internal double @multiply_add(double noundef %0, double noundef %1, double noundef %2) #0 {
  %4 = alloca double, align 8
  %5 = alloca double, align 8
  %6 = alloca double, align 8
  store double %2, ptr %4, align 8
  store double %1, ptr %5, align 8
  store double %0, ptr %6, align 8
  %7 = load double, ptr %6, align 8
  %8 = load double, ptr %5, align 8
  %9 = fmul double %7, %8
  %10 = load double, ptr %4, align 8
  %11 = fadd double %9, %10
  ret double %11
}

attributes #0 = { noinline nounwind optnone uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nounwind "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { nounwind }

!llvm.dbg.cu = !{!0}
!llvm.module.flags = !{!2, !3, !4, !5, !6}
!llvm.ident = !{!7}

!0 = distinct !DICompileUnit(language: DW_LANG_C11, file: !1, producer: "clang version 21.1.0", isOptimized: false, runtimeVersion: 0, emissionKind: NoDebug, splitDebugInlining: false, nameTableKind: None)
!1 = !DIFile(filename: "G:\\Hackathon-stage2-artifacts\\project19\\20261014-development\\acceptance\\s34-memory-ctest-integer-selectors\\blocked-min.c", directory: "F:\\Hackathon\\projects\\19-dynamic-graph")
!2 = !{i32 2, !"Debug Info Version", i32 3}
!3 = !{i32 1, !"wchar_size", i32 2}
!4 = !{i32 8, !"PIC Level", i32 2}
!5 = !{i32 7, !"uwtable", i32 2}
!6 = !{i32 1, !"MaxTLSAlign", i32 65536}
!7 = !{!"clang version 21.1.0"}
!8 = distinct !{!8, !9}
!9 = !{!"llvm.loop.mustprogress"}
!10 = distinct !{!10, !9}
!11 = distinct !{!11, !9}
!12 = distinct !{!12, !9}
!13 = distinct !{!13, !9}
!14 = distinct !{!14, !9}
