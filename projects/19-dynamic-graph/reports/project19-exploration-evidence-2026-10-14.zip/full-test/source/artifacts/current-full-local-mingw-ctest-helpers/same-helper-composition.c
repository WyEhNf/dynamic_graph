static int h(int x){return x+1;}
int transform(const double*a,double*l,int n){for(int i=0;i<n*n;++i)l[i]=h(h(i-n));return 0;}