from pathlib import Path
import datetime,hashlib,json,os,struct,subprocess,sys
ROOT=Path(__file__).resolve().parent; OUT=ROOT/'full-test'; P=Path('F:/Hackathon/projects/19-dynamic-graph')
S=Path('G:/Hackathon-stage2-artifacts/project19/20261013-overnight/structured-owned-reuse')
sys.path.insert(0,str(S));from archive_members import members
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def pe(p):
 b=bytearray(Path(p).read_bytes());off=struct.unpack_from('<I',b,0x3c)[0];assert b[off:off+4]==b'PE\0\0'
 b[off+8:off+12]=b'\0'*4;b[off+88:off+92]=b'\0'*4;return b
fresh=OUT/'build-local-mingw'; a,b,_=members(P/'build/libcholesky_core.a');c,d,_=members(fresh/'libcholesky_core.a')
r=dict(created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),core_raw_members_identical=a==c and b==d,core_members=d,
 main_identical=sha(S/'build/CMakeFiles/cholesky_runtime.dir/src/main.cpp.obj')==sha(fresh/'CMakeFiles/cholesky_runtime.dir/src/main.cpp.obj'),
 full_PE_payload_identical=pe(P/'build/cholesky_runtime.exe')==pe(fresh/'cholesky_runtime.exe'),pipelines=[])
assert r['core_raw_members_identical'] and r['main_identical'] and r['full_PE_payload_identical']
for p in (OUT/'source/artifacts').rglob('*report.json'):
 q=json.loads(p.read_text(encoding='utf-8'));assert q['passed'];rows=[]
 def visit(v):
  if isinstance(v,dict):
   if v.get('byte_identical') is True:rows.append(v)
   for k,x in v.items():
    if k!='byte_identical':visit(x)
  elif isinstance(v,list):
   for x in v:visit(x)
 visit(q)
 r['pipelines'].append(dict(path=str(p),sha256=sha(p),strict_success_runs=len(rows),matrix_executions=sum(x.get('matrices',0) for x in rows),rejections=len(q.get('rejections',q.get('rejection_cases',[])))))
env=dict(os.environ,PYTHONUTF8='1',PYTHONIOENCODING='utf-8',PATH='E:/mingw64/bin;'+os.environ.get('PATH',''))
cmd=[str(P/'.venv/Scripts/python.exe'),'-m','unittest','discover','-s','tests','-p','test_dispatch_profile.py','-v']
x=subprocess.run(cmd,cwd=OUT/'source',env=env,capture_output=True,text=True)
(OUT/'dispatch-python.log').write_text(x.stdout+x.stderr,encoding='utf-8');assert x.returncode==0
r['python_dispatch_tests']=dict(command=cmd,returncode=x.returncode,tests=3,log_sha256=sha(OUT/'dispatch-python.log'))
r['strict_success_runs']=sum(x['strict_success_runs'] for x in r['pipelines']);r['expected_rejections']=sum(x['rejections'] for x in r['pipelines']);r['passed']=True
(OUT/'supplement.json').write_text(json.dumps(r,indent=2)+'\n',encoding='utf-8');print(json.dumps(r),flush=True)
