#include <math.h>
int factor(const double*a,double*l,int n){
int i=0;while(i<n){
  int j=0;while(j<=i){
    double s=0;int k=0;while(k<j){s+=l[i*n+k]*l[j*n+k];k=k+1;}
    if(i==j)l[i*n+j]=sqrt(a[i*n+i]-s);else l[i*n+j]=(a[i*n+j]-s)/l[j*n+j];
    j+=1;
  }i++;
}return 0;}
