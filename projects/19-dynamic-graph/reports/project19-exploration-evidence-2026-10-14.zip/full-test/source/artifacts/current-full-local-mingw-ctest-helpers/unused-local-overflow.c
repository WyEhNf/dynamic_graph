static double h(double x){int ignored=x*1e100;return x;}
int transform(const double*a,double*l,int n){l[0]=h(a[0]);return 0;}