; ModuleID = 'G:\Hackathon-stage2-artifacts\project19\20261014-development\acceptance\s34-memory-ctest-helpers\deep-ssa-20.c'
source_filename = "G:\\Hackathon-stage2-artifacts\\project19\\20261014-development\\acceptance\\s34-memory-ctest-helpers\\deep-ssa-20.c"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-windows-msvc19.44.35228"

; Function Attrs: noinline nounwind optnone uwtable
define dso_local i32 @transform(ptr noundef %0, ptr noundef %1, i32 noundef %2) #0 {
  %4 = alloca i32, align 4
  %5 = alloca ptr, align 8
  %6 = alloca ptr, align 8
  %7 = alloca i32, align 4
  store i32 %2, ptr %4, align 4
  store ptr %1, ptr %5, align 8
  store ptr %0, ptr %6, align 8
  store i32 0, ptr %7, align 4
  br label %8

8:                                                ; preds = %25, %3
  %9 = load i32, ptr %7, align 4
  %10 = load i32, ptr %4, align 4
  %11 = load i32, ptr %4, align 4
  %12 = mul nsw i32 %10, %11
  %13 = icmp slt i32 %9, %12
  br i1 %13, label %14, label %28

14:                                               ; preds = %8
  %15 = load ptr, ptr %6, align 8
  %16 = load i32, ptr %7, align 4
  %17 = sext i32 %16 to i64
  %18 = getelementptr inbounds double, ptr %15, i64 %17
  %19 = load double, ptr %18, align 8
  %20 = call double @h(double noundef %19)
  %21 = load ptr, ptr %5, align 8
  %22 = load i32, ptr %7, align 4
  %23 = sext i32 %22 to i64
  %24 = getelementptr inbounds double, ptr %21, i64 %23
  store double %20, ptr %24, align 8
  br label %25

25:                                               ; preds = %14
  %26 = load i32, ptr %7, align 4
  %27 = add nsw i32 %26, 1
  store i32 %27, ptr %7, align 4
  br label %8, !llvm.loop !8

28:                                               ; preds = %8
  ret i32 0
}

; Function Attrs: noinline nounwind optnone uwtable
define internal double @h(double noundef %0) #0 {
  %2 = alloca double, align 8
  %3 = alloca double, align 8
  %4 = alloca double, align 8
  %5 = alloca double, align 8
  %6 = alloca double, align 8
  %7 = alloca double, align 8
  %8 = alloca double, align 8
  %9 = alloca double, align 8
  %10 = alloca double, align 8
  %11 = alloca double, align 8
  %12 = alloca double, align 8
  %13 = alloca double, align 8
  %14 = alloca double, align 8
  %15 = alloca double, align 8
  %16 = alloca double, align 8
  %17 = alloca double, align 8
  %18 = alloca double, align 8
  %19 = alloca double, align 8
  %20 = alloca double, align 8
  %21 = alloca double, align 8
  %22 = alloca double, align 8
  store double %0, ptr %2, align 8
  %23 = load double, ptr %2, align 8
  %24 = load double, ptr %2, align 8
  %25 = fadd double %23, %24
  %26 = fmul double %25, 5.000000e-01
  store double %26, ptr %3, align 8
  %27 = load double, ptr %3, align 8
  %28 = load double, ptr %3, align 8
  %29 = fadd double %27, %28
  %30 = fmul double %29, 5.000000e-01
  store double %30, ptr %4, align 8
  %31 = load double, ptr %4, align 8
  %32 = load double, ptr %4, align 8
  %33 = fadd double %31, %32
  %34 = fmul double %33, 5.000000e-01
  store double %34, ptr %5, align 8
  %35 = load double, ptr %5, align 8
  %36 = load double, ptr %5, align 8
  %37 = fadd double %35, %36
  %38 = fmul double %37, 5.000000e-01
  store double %38, ptr %6, align 8
  %39 = load double, ptr %6, align 8
  %40 = load double, ptr %6, align 8
  %41 = fadd double %39, %40
  %42 = fmul double %41, 5.000000e-01
  store double %42, ptr %7, align 8
  %43 = load double, ptr %7, align 8
  %44 = load double, ptr %7, align 8
  %45 = fadd double %43, %44
  %46 = fmul double %45, 5.000000e-01
  store double %46, ptr %8, align 8
  %47 = load double, ptr %8, align 8
  %48 = load double, ptr %8, align 8
  %49 = fadd double %47, %48
  %50 = fmul double %49, 5.000000e-01
  store double %50, ptr %9, align 8
  %51 = load double, ptr %9, align 8
  %52 = load double, ptr %9, align 8
  %53 = fadd double %51, %52
  %54 = fmul double %53, 5.000000e-01
  store double %54, ptr %10, align 8
  %55 = load double, ptr %10, align 8
  %56 = load double, ptr %10, align 8
  %57 = fadd double %55, %56
  %58 = fmul double %57, 5.000000e-01
  store double %58, ptr %11, align 8
  %59 = load double, ptr %11, align 8
  %60 = load double, ptr %11, align 8
  %61 = fadd double %59, %60
  %62 = fmul double %61, 5.000000e-01
  store double %62, ptr %12, align 8
  %63 = load double, ptr %12, align 8
  %64 = load double, ptr %12, align 8
  %65 = fadd double %63, %64
  %66 = fmul double %65, 5.000000e-01
  store double %66, ptr %13, align 8
  %67 = load double, ptr %13, align 8
  %68 = load double, ptr %13, align 8
  %69 = fadd double %67, %68
  %70 = fmul double %69, 5.000000e-01
  store double %70, ptr %14, align 8
  %71 = load double, ptr %14, align 8
  %72 = load double, ptr %14, align 8
  %73 = fadd double %71, %72
  %74 = fmul double %73, 5.000000e-01
  store double %74, ptr %15, align 8
  %75 = load double, ptr %15, align 8
  %76 = load double, ptr %15, align 8
  %77 = fadd double %75, %76
  %78 = fmul double %77, 5.000000e-01
  store double %78, ptr %16, align 8
  %79 = load double, ptr %16, align 8
  %80 = load double, ptr %16, align 8
  %81 = fadd double %79, %80
  %82 = fmul double %81, 5.000000e-01
  store double %82, ptr %17, align 8
  %83 = load double, ptr %17, align 8
  %84 = load double, ptr %17, align 8
  %85 = fadd double %83, %84
  %86 = fmul double %85, 5.000000e-01
  store double %86, ptr %18, align 8
  %87 = load double, ptr %18, align 8
  %88 = load double, ptr %18, align 8
  %89 = fadd double %87, %88
  %90 = fmul double %89, 5.000000e-01
  store double %90, ptr %19, align 8
  %91 = load double, ptr %19, align 8
  %92 = load double, ptr %19, align 8
  %93 = fadd double %91, %92
  %94 = fmul double %93, 5.000000e-01
  store double %94, ptr %20, align 8
  %95 = load double, ptr %20, align 8
  %96 = load double, ptr %20, align 8
  %97 = fadd double %95, %96
  %98 = fmul double %97, 5.000000e-01
  store double %98, ptr %21, align 8
  %99 = load double, ptr %21, align 8
  %100 = load double, ptr %21, align 8
  %101 = fadd double %99, %100
  %102 = fmul double %101, 5.000000e-01
  store double %102, ptr %22, align 8
  %103 = load double, ptr %22, align 8
  ret double %103
}

attributes #0 = { noinline nounwind optnone uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }

!llvm.dbg.cu = !{!0}
!llvm.module.flags = !{!2, !3, !4, !5, !6}
!llvm.ident = !{!7}

!0 = distinct !DICompileUnit(language: DW_LANG_C11, file: !1, producer: "clang version 21.1.0", isOptimized: false, runtimeVersion: 0, emissionKind: NoDebug, splitDebugInlining: false, nameTableKind: None)
!1 = !DIFile(filename: "G:\\Hackathon-stage2-artifacts\\project19\\20261014-development\\acceptance\\s34-memory-ctest-helpers\\deep-ssa-20.c", directory: "F:\\Hackathon\\projects\\19-dynamic-graph")
!2 = !{i32 2, !"Debug Info Version", i32 3}
!3 = !{i32 1, !"wchar_size", i32 2}
!4 = !{i32 8, !"PIC Level", i32 2}
!5 = !{i32 7, !"uwtable", i32 2}
!6 = !{i32 1, !"MaxTLSAlign", i32 65536}
!7 = !{!"clang version 21.1.0"}
!8 = distinct !{!8, !9}
!9 = !{!"llvm.loop.mustprogress"}
