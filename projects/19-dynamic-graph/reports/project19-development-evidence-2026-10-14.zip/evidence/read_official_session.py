from pathlib import Path
import http.cookiejar,json,urllib.request,urllib.error,datetime,hashlib
r=Path(__file__).resolve().parent/'official';jar=http.cookiejar.CookieJar();opener=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar))
common={'User-Agent':'Mozilla/5.0','Referer':'https://www.chaspark.com/','Accept':'application/json'}
with opener.open(urllib.request.Request('https://www.chaspark.com/',headers=common),timeout=30) as f:f.read()
headers=dict(common)
for c in jar:
 if c.name=='X-CSRF-TOKEN':headers[c.name]=c.value
urls=[('races-detail','https://www.chaspark.com/api/chaspark-user/rest/chasparkcompetitionservice/v1/races-detail/1326691788365586432'),('content-detail','https://www.chaspark.com/chasiwu/v1/content/races/question/detail?nid=1326691788365586432')]
result=[]
for label,u in urls:
 try:
  with opener.open(urllib.request.Request(u,headers=headers),timeout=30) as f:status=f.status;b=f.read()
 except urllib.error.HTTPError as e:status=e.code;b=e.read()
 (r/(label+'-session-response.txt')).write_bytes(b)
 result.append(dict(label=label,url=u,status=status,bytes=len(b),sha256=hashlib.sha256(b).hexdigest()))
 print(label,status,b.decode('utf-8',errors='replace')[:3000],flush=True)
(r/'session-provenance.json').write_text(json.dumps(dict(fetched_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),method='Ordinary public HTTP session; only cookies supplied by current site root. No saved browser credentials.',responses=result),indent=2)+'\n',encoding='utf-8')
