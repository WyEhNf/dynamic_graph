"""Current-version correctness portion of the published structured workload suite.
No historical candidate/baseline performance or old geometry assertions included.
"""
from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys,time
ROOT=Path(__file__).resolve().parent;WS=ROOT/'full-test/source';OUT=ROOT/'structured-test';OUT.mkdir(exist_ok=True)
assert not (OUT/'report.json').exists()
sys.path.insert(0,str(WS/'tools'))
from analyze_source import analyze
from evaluate_source import compile_oracle,run_runtime,exact_compare
from structured_workloads import make_workload
env=dict(os.environ,PATH='E:/mingw64/bin;C:/Program Files/LLVM/bin;'+os.environ.get('PATH',''),TEMP=str(OUT),TMP=str(OUT),PYTHONUTF8='1',PYTHONIOENCODING='utf-8');os.environ.update(env)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
native=Path('F:/Hackathon/projects/19-dynamic-graph/build/cholesky_runtime.exe');memory=ROOT/'full-test/build-memory-mingw/cholesky_runtime.exe'
assert sha(native)=='912c9fec8ac5e1793d6217afc5c3b09f49a8b8e536f273eeaef9b94a69072eba'
fma=OUT/'explicit-fma.c';text=(WS/'fixtures/official_naive_transcribed.c').read_text(encoding='utf-8');assert 'return x * y + z;' in text;fma.write_text(text.replace('return x * y + z;','return fma(x,y,z);'),encoding='utf-8')
sources=[('scalar',WS/'fixtures/cholesky_reference.c','cholesky_reference',False),('page',WS/'fixtures/official_naive_transcribed.c','cholesky',False),('blocked',WS/'fixtures/cholesky_blocked.c','cholesky_blocked',True),('fma',fma,'cholesky',False)]
r=dict(status='running',started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='All380 correctness entries of published structured suite for each current preset; no historical performance experiments, no oracle regeneration at maximum N.',profiles=dict(local=sha(native),memory=sha(memory)),sources=[],records=[],metadata_modes=[])
def save():(OUT/'report.json').write_text(json.dumps(r,indent=2)+'\n',encoding='utf-8')
metas={};oracles={};save()
for label,source,function,blocked in sources:
 folder=OUT/label;folder.mkdir();metas[label]=folder/'program.meta';analyze(source,metas[label],'clang',function);oracles[label]=compile_oracle(source,function,folder/'oracle-build','gcc',blocked)
 r['sources'].append(dict(label=label,source=str(source),source_sha256=sha(source),oracle_exe_sha256=sha(oracles[label]),metadata_sha256=sha(metas[label])));save()
configs=[dict(engine='auto',threads=4),dict(engine='stage',threads=1),dict(engine='tiled',tile_size=7,threads=4),dict(engine='tiled',tile_size=32,threads=4,structure='dense',simd='portable'),dict(engine='tiled',tile_size=64,threads=4,structure='dense',ready_queue='bucket'),dict(engine='tiled',tile_size=32,threads=4,band_limit=0)]
jobs=[]
for width,sizes in ((1,[3,7,17,33,65,129,193]),(7,[3,7,17,33,65,129,193]),(31,[65,129,193]),(127,[257,513,517]),(128,[513,517]),(129,[517])):
 for mode in (('normal','subnormal','large','tiny') if width<=31 else ('normal',)):jobs.append((f'band-{width}-{mode}',sizes,'band',width,mode,configs))
jobs += [('small-vm',[3,7,17,33],'band',1,'tiny',[dict(engine='vm',threads=4)]),('toeplitz',[257,1025,2047,2048,2049],'toeplitz',1,'normal',[dict(engine='tiled',tile_size='auto',threads=t) for t in (1,4)]),('low-rank',[257,1025,2047,2048,2049],'low-rank',1,'normal',[dict(engine='tiled',tile_size='auto',threads=t) for t in (1,4)])]
for tag,sizes,family,width,mode,cfgs in jobs:
 folder=OUT/tag;folder.mkdir();ip=folder/'input.bin';make_workload(ip,sizes,family,width,mode)
 for label,_,_,_ in sources:
  ref=folder/(label+'-oracle.bin');subprocess.run([str(oracles[label]),str(ip),str(ref),'7'],check=True)
  for profile,exe in (('local',native),('memory',memory)):
   for index,cfg in enumerate(cfgs):
    dst=folder/(label+'-'+profile+f'-c{index}.bin');metrics=run_runtime(exe,metas[label],ip,dst,block=7,**cfg);v=exact_compare(ref,dst)
    r['records'].append(dict(profile=profile,case=tag,source=label,sizes=sizes,family=family,width=width,mode=mode,config=cfg,metrics=metrics,validation=v));save();dst.unlink()
  ref.unlink()
 ip.unlink();print(json.dumps(dict(case=tag,passed=True,completed=len(r['records']))),flush=True)
# Published expanded/DAG/no-inline/compact forms, same current source/runtime.
small=OUT/'metadata-variants';small.mkdir();ip=small/'input.bin';make_workload(ip,[3,7,17,33],'band',1,'normal')
for label,source,function,blocked in sources[:3]:
 folder=small/label;folder.mkdir();ref=folder/'oracle.bin';subprocess.run([str(oracles[label]),str(ip),str(ref),'7'],check=True)
 for expr,inline,compact in [('expanded',True,False),('dag',True,False),('dag',False,False),('dag',False,True)]:
  meta=folder/f'{expr}-{inline}-{compact}.meta';analyze(source,meta,'clang',function,expr,inline,compact)
  for profile,exe in (('local',native),('memory',memory)):
   for engine in ('vm','tiled'):
    dst=folder/'out.bin';metrics=run_runtime(exe,meta,ip,dst,engine=engine,tile_size=7,threads=4,block=7,ready_queue='bucket');v=exact_compare(ref,dst)
    r['metadata_modes'].append(dict(source=label,profile=profile,expression_mode=expr,inline=inline,compact=compact,engine=engine,metrics=metrics,validation=v));save();dst.unlink()
counts={k:sum(x['profile']==k for x in r['records']) for k in ('local','memory')};assert counts==dict(local=380,memory=380)
r.update(status='completed',passed=True,structured_success_runs=len(r['records']),metadata_success_runs=len(r['metadata_modes']),counts=counts,finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());save()
print(json.dumps(dict(passed=True,structured=len(r['records']),metadata=len(r['metadata_modes']))),flush=True)
