from pathlib import Path
import datetime,hashlib,json,os,struct,sys
ROOT=Path(__file__).resolve().parent;P=Path('F:/Hackathon/projects/19-dynamic-graph');OUT=ROOT/'scale-test';OUT.mkdir(exist_ok=True)
assert not (OUT/'report.json').exists()
sys.path.insert(0,str(P/'tools'));from windows_file_resource_probe_stage2 import monitored_run
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
 return h.hexdigest()
def compare(dst,oracles):
 h=hashlib.sha256();total=0
 with dst.open('rb') as f:
  b=f.read(4);assert b==struct.pack('<I',len(oracles));h.update(b);total+=4
  for ref in oracles:
   with Path(ref).open('rb') as o:
    o.seek(4)
    for b in iter(lambda:o.read(8*1024*1024),b''):
     x=f.read(len(b));assert b==x;h.update(x);total+=len(x)
  assert f.read(1)==b''
 return dict(full_byte_comparison=True,bytes=total,sha256=h.hexdigest())
base=P/'artifacts';d=base/'simd-milestone/dense-4096';m=base/'maximum-dense-oracle';b=base/'band-maximum-reference'
mixed=Path('G:/Hackathon-stage2-artifacts/project19/20261013-overnight/combined-next/acceptance/large/mixed-input.bin')
assert sha(mixed)=='9d5a43aba4ab01c71f1aa27d23b55d549973ad7c7dfb272c46381a878000cc60'
trim=OUT/'dense-band-dense.bin'
with trim.open('wb') as f:
 f.write(struct.pack('<I',3))
 for src in (d/'input.bin',b/'input.bin',d/'input.bin'):
  with src.open('rb') as inp:
   inp.seek(4)
   for block in iter(lambda:inp.read(8*1024*1024),b''):f.write(block)
native=P/'build/cholesky_runtime.exe';memory=ROOT/'full-test/build-memory-mingw/cholesky_runtime.exe'
meta=Path('G:/Hackathon-stage2-artifacts/project19/20261013-evening/native-optimization/official.meta')
assert sha(native)=='912c9fec8ac5e1793d6217afc5c3b09f49a8b8e536f273eeaef9b94a69072eba'
cases=[(f'local-mixed-{mode}',native,mixed,[d/'oracle.bin',m/'oracle.bin',d/'oracle.bin'],mode) for mode in ('off','session','session-trim')]
cases += [('local-dense-band-dense-trim',native,trim,[d/'oracle.bin',b/'oracle.bin',d/'oracle.bin'],'session-trim'),('memory-dense10000',memory,m/'input.bin',[m/'oracle.bin'],'off')]
r=dict(status='running',started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='Additional full-scale correctness, not a performance experiment. Cached independent original-C outputs reused; no original-C regeneration.',metadata_sha256=sha(meta),mixed_input_sha256=sha(mixed),trim_input_sha256=sha(trim),cases=[])
def save():(OUT/'report.json').write_text(json.dumps(r,indent=2)+'\n',encoding='utf-8')
os.environ.update(PATH='E:/mingw64/bin;'+os.environ.get('PATH',''),TEMP=str(OUT),TMP=str(OUT))
save()
for name,exe,inp,refs,mode in cases:
 dst=OUT/(name+'.bin');cmd=[str(exe),'--metadata',str(meta),'--input',str(inp),'--output',str(dst),'--scheduler','parallel','--threads','16','--native-workspace',mode]
 x,res=monitored_run(cmd,OUT/(name+'.stdout'),OUT/(name+'.stderr'),check=False,timeout=180);assert x.returncode==0,(name,x.stderr)
 metrics=json.loads(x.stdout);v=compare(dst,refs)
 r['cases'].append(dict(name=name,command=cmd,runtime_sha256=sha(exe),metrics=metrics,resources=res,validation=v,oracle_files=[str(x) for x in refs]));save();print(json.dumps(dict(case=name,passed=True,bytes=v['bytes'])),flush=True)
r.update(status='completed',passed=True,processes=len(cases),matrix_executions=13,finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());save()
print(json.dumps(dict(passed=True,processes=len(cases))),flush=True)
