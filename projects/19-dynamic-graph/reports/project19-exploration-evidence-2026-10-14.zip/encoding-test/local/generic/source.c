#include <math.h>
int transform(const double *a,double *l,int n) {
  int i=0;
  while(i<n*n) {
    int q=i/3; int r=i%3;
    double x=a[i];
    if (!(x<0.0) && q>=0) l[i]=fma(fmin(fabs(x),4.0),0.5,fmax(sqrt(fabs(x)),1.0));
    else l[i]=r!=0 ? -x : x/2.0;
    i=i+1;
  }
  return 0;
}
