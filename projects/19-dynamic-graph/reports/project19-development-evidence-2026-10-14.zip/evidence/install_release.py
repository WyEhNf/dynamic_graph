from pathlib import Path
import datetime,hashlib,json,shutil
R=Path(__file__).resolve().parent;P=Path('F:/Hackathon/projects/19-dynamic-graph')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
r=json.loads((R/'release-manifest.json').read_text());assert r['status']=='validated_not_installed'
assert all(sha(P/name)==value for name,value in r['source_sha256'].items())
for file in (R/'acceptance').rglob('*report.json'):assert json.loads(file.read_text())['passed'],file
for file in ['smallest-acceptance/report.json','scale-acceptance/report.json','default-audit/report.json']:
    assert json.loads((R/file).read_text())['passed'],file
for name,total in [('local',18),('memory',13)]:
    text=(R/f'ctest-{name}.log').read_text()
    assert f'0 tests failed out of {total}' in text
    assert '0 tests failed out of 1' in (R/('ctest-packed-final-portable.log' if name=='local' else 'ctest-memory-packed-final.log')).read_text()
backup=R/'rollback';backup.mkdir(exist_ok=False)
for profile,build in [('local','build'),('memory','build-memory')]:
    previous={};installed={};(backup/profile).mkdir()
    for file,key in [('cholesky_runtime.exe','runtime_sha256'),('libcholesky_core.a','core_sha256')]:
        src=R/build/file;dst=P/build/file
        assert sha(src)==r['profiles'][profile][key]
        if dst.exists():shutil.copyfile(dst,backup/profile/file);previous[file]=sha(dst)
        dst.parent.mkdir(exist_ok=True);shutil.copyfile(src,dst)
        installed[file]=sha(dst);assert installed[file]==r['profiles'][profile][key]
    r['profiles'][profile].update(installed_build=str(P/build),installed_sha256=installed,rollback_sha256=previous)
r.update(status='installed_validated',installed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
(R/'release-manifest.json').write_text(json.dumps(r,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(status=r['status'],profiles={k:v['installed_sha256'] for k,v in r['profiles'].items()}),indent=2))
