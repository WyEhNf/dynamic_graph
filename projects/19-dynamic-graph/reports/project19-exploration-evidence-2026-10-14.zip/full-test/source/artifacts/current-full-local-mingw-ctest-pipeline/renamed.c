/* Self-built fixture, not the official competition source. */
#include <math.h>
int decompose(const double *input_matrix, double *factor, int extent) {
  for (int row = 0; row < extent; row += 1) {
    for (int column = 0; column <= row; column = column + 1) {
      double accumulator = 0.0;
      for (int depth = 0; depth < column; depth++) {
        accumulator += factor[row*extent+depth] * factor[column*extent+depth];
      }
      if (row == column) factor[row*extent+column] = sqrt(input_matrix[row*extent+row] - accumulator);
      else factor[row*extent+column] = (input_matrix[row*extent+column] - accumulator) / factor[column*extent+column];
    }
  }
  return 0;
}
