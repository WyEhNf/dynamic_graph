; ModuleID = 'G:\Hackathon-stage2-artifacts\project19\20261014-development\acceptance\s34-memory-ctest-helpers\deep-ssa-40.c'
source_filename = "G:\\Hackathon-stage2-artifacts\\project19\\20261014-development\\acceptance\\s34-memory-ctest-helpers\\deep-ssa-40.c"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-windows-msvc19.44.35228"

; Function Attrs: noinline nounwind optnone uwtable
define dso_local i32 @transform(ptr noundef %0, ptr noundef %1, i32 noundef %2) #0 {
  %4 = alloca i32, align 4
  %5 = alloca ptr, align 8
  %6 = alloca ptr, align 8
  %7 = alloca i32, align 4
  store i32 %2, ptr %4, align 4
  store ptr %1, ptr %5, align 8
  store ptr %0, ptr %6, align 8
  store i32 0, ptr %7, align 4
  br label %8

8:                                                ; preds = %25, %3
  %9 = load i32, ptr %7, align 4
  %10 = load i32, ptr %4, align 4
  %11 = load i32, ptr %4, align 4
  %12 = mul nsw i32 %10, %11
  %13 = icmp slt i32 %9, %12
  br i1 %13, label %14, label %28

14:                                               ; preds = %8
  %15 = load ptr, ptr %6, align 8
  %16 = load i32, ptr %7, align 4
  %17 = sext i32 %16 to i64
  %18 = getelementptr inbounds double, ptr %15, i64 %17
  %19 = load double, ptr %18, align 8
  %20 = call double @h(double noundef %19)
  %21 = load ptr, ptr %5, align 8
  %22 = load i32, ptr %7, align 4
  %23 = sext i32 %22 to i64
  %24 = getelementptr inbounds double, ptr %21, i64 %23
  store double %20, ptr %24, align 8
  br label %25

25:                                               ; preds = %14
  %26 = load i32, ptr %7, align 4
  %27 = add nsw i32 %26, 1
  store i32 %27, ptr %7, align 4
  br label %8, !llvm.loop !8

28:                                               ; preds = %8
  ret i32 0
}

; Function Attrs: noinline nounwind optnone uwtable
define internal double @h(double noundef %0) #0 {
  %2 = alloca double, align 8
  %3 = alloca double, align 8
  %4 = alloca double, align 8
  %5 = alloca double, align 8
  %6 = alloca double, align 8
  %7 = alloca double, align 8
  %8 = alloca double, align 8
  %9 = alloca double, align 8
  %10 = alloca double, align 8
  %11 = alloca double, align 8
  %12 = alloca double, align 8
  %13 = alloca double, align 8
  %14 = alloca double, align 8
  %15 = alloca double, align 8
  %16 = alloca double, align 8
  %17 = alloca double, align 8
  %18 = alloca double, align 8
  %19 = alloca double, align 8
  %20 = alloca double, align 8
  %21 = alloca double, align 8
  %22 = alloca double, align 8
  %23 = alloca double, align 8
  %24 = alloca double, align 8
  %25 = alloca double, align 8
  %26 = alloca double, align 8
  %27 = alloca double, align 8
  %28 = alloca double, align 8
  %29 = alloca double, align 8
  %30 = alloca double, align 8
  %31 = alloca double, align 8
  %32 = alloca double, align 8
  %33 = alloca double, align 8
  %34 = alloca double, align 8
  %35 = alloca double, align 8
  %36 = alloca double, align 8
  %37 = alloca double, align 8
  %38 = alloca double, align 8
  %39 = alloca double, align 8
  %40 = alloca double, align 8
  %41 = alloca double, align 8
  %42 = alloca double, align 8
  store double %0, ptr %2, align 8
  %43 = load double, ptr %2, align 8
  %44 = load double, ptr %2, align 8
  %45 = fadd double %43, %44
  %46 = fmul double %45, 5.000000e-01
  store double %46, ptr %3, align 8
  %47 = load double, ptr %3, align 8
  %48 = load double, ptr %3, align 8
  %49 = fadd double %47, %48
  %50 = fmul double %49, 5.000000e-01
  store double %50, ptr %4, align 8
  %51 = load double, ptr %4, align 8
  %52 = load double, ptr %4, align 8
  %53 = fadd double %51, %52
  %54 = fmul double %53, 5.000000e-01
  store double %54, ptr %5, align 8
  %55 = load double, ptr %5, align 8
  %56 = load double, ptr %5, align 8
  %57 = fadd double %55, %56
  %58 = fmul double %57, 5.000000e-01
  store double %58, ptr %6, align 8
  %59 = load double, ptr %6, align 8
  %60 = load double, ptr %6, align 8
  %61 = fadd double %59, %60
  %62 = fmul double %61, 5.000000e-01
  store double %62, ptr %7, align 8
  %63 = load double, ptr %7, align 8
  %64 = load double, ptr %7, align 8
  %65 = fadd double %63, %64
  %66 = fmul double %65, 5.000000e-01
  store double %66, ptr %8, align 8
  %67 = load double, ptr %8, align 8
  %68 = load double, ptr %8, align 8
  %69 = fadd double %67, %68
  %70 = fmul double %69, 5.000000e-01
  store double %70, ptr %9, align 8
  %71 = load double, ptr %9, align 8
  %72 = load double, ptr %9, align 8
  %73 = fadd double %71, %72
  %74 = fmul double %73, 5.000000e-01
  store double %74, ptr %10, align 8
  %75 = load double, ptr %10, align 8
  %76 = load double, ptr %10, align 8
  %77 = fadd double %75, %76
  %78 = fmul double %77, 5.000000e-01
  store double %78, ptr %11, align 8
  %79 = load double, ptr %11, align 8
  %80 = load double, ptr %11, align 8
  %81 = fadd double %79, %80
  %82 = fmul double %81, 5.000000e-01
  store double %82, ptr %12, align 8
  %83 = load double, ptr %12, align 8
  %84 = load double, ptr %12, align 8
  %85 = fadd double %83, %84
  %86 = fmul double %85, 5.000000e-01
  store double %86, ptr %13, align 8
  %87 = load double, ptr %13, align 8
  %88 = load double, ptr %13, align 8
  %89 = fadd double %87, %88
  %90 = fmul double %89, 5.000000e-01
  store double %90, ptr %14, align 8
  %91 = load double, ptr %14, align 8
  %92 = load double, ptr %14, align 8
  %93 = fadd double %91, %92
  %94 = fmul double %93, 5.000000e-01
  store double %94, ptr %15, align 8
  %95 = load double, ptr %15, align 8
  %96 = load double, ptr %15, align 8
  %97 = fadd double %95, %96
  %98 = fmul double %97, 5.000000e-01
  store double %98, ptr %16, align 8
  %99 = load double, ptr %16, align 8
  %100 = load double, ptr %16, align 8
  %101 = fadd double %99, %100
  %102 = fmul double %101, 5.000000e-01
  store double %102, ptr %17, align 8
  %103 = load double, ptr %17, align 8
  %104 = load double, ptr %17, align 8
  %105 = fadd double %103, %104
  %106 = fmul double %105, 5.000000e-01
  store double %106, ptr %18, align 8
  %107 = load double, ptr %18, align 8
  %108 = load double, ptr %18, align 8
  %109 = fadd double %107, %108
  %110 = fmul double %109, 5.000000e-01
  store double %110, ptr %19, align 8
  %111 = load double, ptr %19, align 8
  %112 = load double, ptr %19, align 8
  %113 = fadd double %111, %112
  %114 = fmul double %113, 5.000000e-01
  store double %114, ptr %20, align 8
  %115 = load double, ptr %20, align 8
  %116 = load double, ptr %20, align 8
  %117 = fadd double %115, %116
  %118 = fmul double %117, 5.000000e-01
  store double %118, ptr %21, align 8
  %119 = load double, ptr %21, align 8
  %120 = load double, ptr %21, align 8
  %121 = fadd double %119, %120
  %122 = fmul double %121, 5.000000e-01
  store double %122, ptr %22, align 8
  %123 = load double, ptr %22, align 8
  %124 = load double, ptr %22, align 8
  %125 = fadd double %123, %124
  %126 = fmul double %125, 5.000000e-01
  store double %126, ptr %23, align 8
  %127 = load double, ptr %23, align 8
  %128 = load double, ptr %23, align 8
  %129 = fadd double %127, %128
  %130 = fmul double %129, 5.000000e-01
  store double %130, ptr %24, align 8
  %131 = load double, ptr %24, align 8
  %132 = load double, ptr %24, align 8
  %133 = fadd double %131, %132
  %134 = fmul double %133, 5.000000e-01
  store double %134, ptr %25, align 8
  %135 = load double, ptr %25, align 8
  %136 = load double, ptr %25, align 8
  %137 = fadd double %135, %136
  %138 = fmul double %137, 5.000000e-01
  store double %138, ptr %26, align 8
  %139 = load double, ptr %26, align 8
  %140 = load double, ptr %26, align 8
  %141 = fadd double %139, %140
  %142 = fmul double %141, 5.000000e-01
  store double %142, ptr %27, align 8
  %143 = load double, ptr %27, align 8
  %144 = load double, ptr %27, align 8
  %145 = fadd double %143, %144
  %146 = fmul double %145, 5.000000e-01
  store double %146, ptr %28, align 8
  %147 = load double, ptr %28, align 8
  %148 = load double, ptr %28, align 8
  %149 = fadd double %147, %148
  %150 = fmul double %149, 5.000000e-01
  store double %150, ptr %29, align 8
  %151 = load double, ptr %29, align 8
  %152 = load double, ptr %29, align 8
  %153 = fadd double %151, %152
  %154 = fmul double %153, 5.000000e-01
  store double %154, ptr %30, align 8
  %155 = load double, ptr %30, align 8
  %156 = load double, ptr %30, align 8
  %157 = fadd double %155, %156
  %158 = fmul double %157, 5.000000e-01
  store double %158, ptr %31, align 8
  %159 = load double, ptr %31, align 8
  %160 = load double, ptr %31, align 8
  %161 = fadd double %159, %160
  %162 = fmul double %161, 5.000000e-01
  store double %162, ptr %32, align 8
  %163 = load double, ptr %32, align 8
  %164 = load double, ptr %32, align 8
  %165 = fadd double %163, %164
  %166 = fmul double %165, 5.000000e-01
  store double %166, ptr %33, align 8
  %167 = load double, ptr %33, align 8
  %168 = load double, ptr %33, align 8
  %169 = fadd double %167, %168
  %170 = fmul double %169, 5.000000e-01
  store double %170, ptr %34, align 8
  %171 = load double, ptr %34, align 8
  %172 = load double, ptr %34, align 8
  %173 = fadd double %171, %172
  %174 = fmul double %173, 5.000000e-01
  store double %174, ptr %35, align 8
  %175 = load double, ptr %35, align 8
  %176 = load double, ptr %35, align 8
  %177 = fadd double %175, %176
  %178 = fmul double %177, 5.000000e-01
  store double %178, ptr %36, align 8
  %179 = load double, ptr %36, align 8
  %180 = load double, ptr %36, align 8
  %181 = fadd double %179, %180
  %182 = fmul double %181, 5.000000e-01
  store double %182, ptr %37, align 8
  %183 = load double, ptr %37, align 8
  %184 = load double, ptr %37, align 8
  %185 = fadd double %183, %184
  %186 = fmul double %185, 5.000000e-01
  store double %186, ptr %38, align 8
  %187 = load double, ptr %38, align 8
  %188 = load double, ptr %38, align 8
  %189 = fadd double %187, %188
  %190 = fmul double %189, 5.000000e-01
  store double %190, ptr %39, align 8
  %191 = load double, ptr %39, align 8
  %192 = load double, ptr %39, align 8
  %193 = fadd double %191, %192
  %194 = fmul double %193, 5.000000e-01
  store double %194, ptr %40, align 8
  %195 = load double, ptr %40, align 8
  %196 = load double, ptr %40, align 8
  %197 = fadd double %195, %196
  %198 = fmul double %197, 5.000000e-01
  store double %198, ptr %41, align 8
  %199 = load double, ptr %41, align 8
  %200 = load double, ptr %41, align 8
  %201 = fadd double %199, %200
  %202 = fmul double %201, 5.000000e-01
  store double %202, ptr %42, align 8
  %203 = load double, ptr %42, align 8
  ret double %203
}

attributes #0 = { noinline nounwind optnone uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }

!llvm.dbg.cu = !{!0}
!llvm.module.flags = !{!2, !3, !4, !5, !6}
!llvm.ident = !{!7}

!0 = distinct !DICompileUnit(language: DW_LANG_C11, file: !1, producer: "clang version 21.1.0", isOptimized: false, runtimeVersion: 0, emissionKind: NoDebug, splitDebugInlining: false, nameTableKind: None)
!1 = !DIFile(filename: "G:\\Hackathon-stage2-artifacts\\project19\\20261014-development\\acceptance\\s34-memory-ctest-helpers\\deep-ssa-40.c", directory: "F:\\Hackathon\\projects\\19-dynamic-graph")
!2 = !{i32 2, !"Debug Info Version", i32 3}
!3 = !{i32 1, !"wchar_size", i32 2}
!4 = !{i32 8, !"PIC Level", i32 2}
!5 = !{i32 7, !"uwtable", i32 2}
!6 = !{i32 1, !"MaxTLSAlign", i32 65536}
!7 = !{!"clang version 21.1.0"}
!8 = distinct !{!8, !9}
!9 = !{!"llvm.loop.mustprogress"}
