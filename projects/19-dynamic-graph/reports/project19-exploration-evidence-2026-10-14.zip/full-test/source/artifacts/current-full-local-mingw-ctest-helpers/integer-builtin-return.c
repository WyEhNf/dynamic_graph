extern int sqrt(double);
int transform(const double*a,double*l,int n){l[0]=sqrt(a[0]);return 0;}