static double h(double x){x+=1;return x;}
int transform(const double*a,double*l,int n){l[0]=h(a[0]);return 0;}