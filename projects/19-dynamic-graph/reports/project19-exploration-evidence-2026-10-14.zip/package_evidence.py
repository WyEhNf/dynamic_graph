"""Package lightweight audit material; never duplicate multi-GB matrix data."""
from pathlib import Path
import datetime,hashlib,json,shutil,zipfile,xml.etree.ElementTree as ET
ROOT=Path(__file__).resolve().parent;P=Path('F:/Hackathon/projects/19-dynamic-graph');DEST=P/'reports';DEST.mkdir(exist_ok=True)
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
reports=[ROOT/x for x in ('full-test/report.json','full-test/supplement.json','structured-test/report.json','encoding-test/report.json','scale-test/report.json','industry-benchmark/report.json')]
assert all(read(p)['passed'] for p in reports)
f=read(reports[0]);b=read(reports[-1]);s=read(ROOT/'structured-test/report.json');e=read(ROOT/'encoding-test/report.json');supp=read(ROOT/'full-test/supplement.json')
for name,h in f['source_sha256'].items():assert sha(P/name)==sha(ROOT/'full-test/source'/name)==h,name
assert sha(f['installed_runtime']['path'])==f['installed_runtime']['sha256'];assert sha(f['installed_core']['path'])==f['installed_core']['sha256']
totals=dict(ctest_registered=25,ctest_failed=0,ctest_skipped=0,python_unit_tests=3,independent_C_success_runs=supp['strict_success_runs']+len(s['records'])+len(s['metadata_modes'])+e['success_runs'],expected_rejections=supp['expected_rejections']+e['expected_rejections'],additional_current_large_CLI_runs=29,industry_processes=b['processes'],source_files=len(f['source_sha256']))
assert totals['independent_C_success_runs']==1666 and totals['expected_rejections']==118
validation=dict(passed=True,created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='Current S33 all registered presets plus published structured/metadata correctness, explicit encoding choice, feature-OFF rejection, max/dynamic scale and same-host library comparison.',totals=totals,production_runtime=f['installed_runtime'],production_core=f['installed_core'],source_integrity_all206=True,full_test_object_PE_bridge=read(ROOT/'full-test/supplement.json')['full_PE_payload_identical'],reports=[dict(path=str(p),sha256=sha(p)) for p in reports],limits=['No official hidden package/helper/CPU score', 'Not arbitrary C', 'No ARM or other OS validation', 'Three-pair shared-host library samples; all outliers retained', 'Library numerical error is factor-to-C comparison, not a new residual/conditioning campaign', 'Optional rejected or disabled research branches are not current production capabilities'])
(ROOT/'validation-summary.json').write_text(json.dumps(validation,indent=2)+'\n',encoding='utf-8')
files=set(ROOT.glob('*.py'))|set(ROOT.glob('*.json'))
files.update(ROOT/'full-test/source'/name for name in f['source_sha256'])
for folder in ('full-test','structured-test','encoding-test','scale-test','industry-benchmark'):
 for p in (ROOT/folder).rglob('*'):
  if not p.is_file():continue
  if folder=='full-test' and ('build-local-mingw' in p.parts or 'build-memory-mingw' in p.parts):continue
  if p.suffix.lower() in ('.json','.xml','.log','.stdout','.stderr','.c','.h','.hpp','.cpp','.py','.txt','.meta','.md'):files.add(p)
files={p for p in files if '__pycache__' not in p.parts and p.name not in ('evidence-index.json','deliverables.json') and p.stat().st_size<16*1024*1024}
# Original independent-C provenance and accepted stage ledger are small read-only inputs.
external=[P/'artifacts/project19-stage-metrics-2026-10-13.json',P/'artifacts/project19-stage-manifest-2026-10-13.json',P/'artifacts/maximum-dense-oracle/reference-provenance.json',P/'artifacts/band-maximum-reference/reference-report.json',P/'artifacts/simd-milestone/dense-4096/reference-provenance.json',Path('G:/Hackathon-stage2-artifacts/project19/20261013-overnight/structured-owned-reuse/screen/report.json')]
pdf=ROOT/'output/pdf/project19-exploration-2026-10-14.pdf';assert pdf.exists();files.add(pdf)
index=dict(created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),included=[],excluded='All matrix input/output/oracle binaries, all build products, dependency DLLs, intermediate PNGs. Large-file paths/hashes remain in reports; recreate from documented provenance if original storage is unavailable.')
for p in sorted(files):index['included'].append(dict(archive_path=str(p.relative_to(ROOT)).replace('\\','/'),source_path=str(p),bytes=p.stat().st_size,sha256=sha(p)))
for p in external:
 name=str(p.relative_to(P/'artifacts')).replace('\\','/') if p.is_relative_to(P/'artifacts') else 's33-screen/report.json'
 index['included'].append(dict(archive_path='historical-provenance/'+name,source_path=str(p),bytes=p.stat().st_size,sha256=sha(p)))
assert len({x['archive_path'] for x in index['included']})==len(index['included'])
(ROOT/'evidence-index.json').write_text(json.dumps(index,indent=2)+'\n',encoding='utf-8')
archive=DEST/'project19-exploration-evidence-2026-10-14.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for x in index['included']:z.write(x['source_path'],x['archive_path'])
 z.write(ROOT/'evidence-index.json','evidence-index.json')
target=DEST/pdf.name;shutil.copy2(pdf,target)
for name in ('build_report.py','report-content.json','validation-summary.json','evidence-index.json'):
 dst=DEST/('project19-exploration-'+name if name=='build_report.py' else 'project19-exploration-'+name);shutil.copy2(ROOT/name,dst)
deliv=dict(pdf=dict(path=str(target),bytes=target.stat().st_size,sha256=sha(target)),archive=dict(path=str(archive),bytes=archive.stat().st_size,sha256=sha(archive)),totals=totals)
(ROOT/'deliverables.json').write_text(json.dumps(deliv,indent=2)+'\n',encoding='utf-8')
print(json.dumps(deliv),flush=True)
