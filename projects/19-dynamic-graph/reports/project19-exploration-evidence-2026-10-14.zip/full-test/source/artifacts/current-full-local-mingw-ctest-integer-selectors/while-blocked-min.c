static int choose(int x,int y){return x<y?x:y;}
#include <math.h>
static double division(double x,double y){return x/y;}
static double madd(double x,double y,double z){return x*y+z;}
int factor(const double*a,double*l,int n,int block){
int panel=0;while(panel<n){
  int panel_end=choose(panel+block,n);
  int i=panel;while(i<panel_end){
    l[i*n+i]=sqrt(a[i*n+i]-l[i*n+i]);
    int row_tile=i+1;while(row_tile<n){
      int row_end=choose(row_tile+block,n);
      int j=row_tile;while(j<row_end){
        l[j*n+i]=division(a[j*n+i]-l[j*n+i],l[i*n+i]);
        int col_tile=i+1;while(col_tile<=j){
          int col_end=choose(col_tile+block,j+1);
          int k=col_tile;while(k<col_end){l[j*n+k]=madd(l[j*n+i],l[k*n+i],l[j*n+k]);k++;}
          col_tile+=block;
        }j++;
      }row_tile+=block;
    }++i;
  }panel+=block;
}return 0;}
