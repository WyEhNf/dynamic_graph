from pathlib import Path
import json,urllib.request,datetime,hashlib
r=Path(__file__).resolve().parent/'official'
u='https://www.chaspark.com/api/chaspark-user/rest/chasparkcompetitionservice/v1/races-detail/1326691788365586432'
req=urllib.request.Request(u,headers={'User-Agent':'Mozilla/5.0','Referer':'https://www.chaspark.com/','Accept':'application/json'})
with urllib.request.urlopen(req,timeout=30) as f:b=f.read()
(r/'detail-response.json').write_bytes(b)
q=json.loads(b);print(json.dumps(q,ensure_ascii=False)[:18000],flush=True)
(r/'fetch-provenance.json').write_text(json.dumps(dict(url=u,requested_page='https://www.chaspark.com/#/races/competitions/1326691788365586432',fetched_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),endpoint_source='Public frontend main.f06855d3.js getRaceUnionDetailApi'),indent=2)+'\n',encoding='utf-8')
