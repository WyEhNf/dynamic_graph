from pathlib import Path
import json,re,urllib.request,urllib.parse
r=Path(__file__).resolve().parent/'official'
for label,u in [('frontend','https://www.chaspark.com/pkg/chaspark-frontend-portal/latest/index.html'),('framework','https://www.chaspark.com/pkg/chaspark-framework-portal/latest/index.html')]:
 try:
  with urllib.request.urlopen(u,timeout=20) as f:b=f.read()
  (r/(label+'.html')).write_bytes(b);s=b.decode();urls=re.findall(r'<script[^>]+src=["\x27]([^"\x27]+)',s);print(json.dumps(dict(label=label,bytes=len(b),scripts=urls)),flush=True)
  for i,u2 in enumerate(urls):
   if 'assets/index-' not in u2:continue
   with urllib.request.urlopen(urllib.parse.urljoin(u,u2),timeout=20) as f:b2=f.read()
   (r/(label+f'-{i}.js')).write_bytes(b2);print('script',label,len(b2),flush=True)
 except Exception as e:print(label,type(e).__name__,str(e),flush=True)
