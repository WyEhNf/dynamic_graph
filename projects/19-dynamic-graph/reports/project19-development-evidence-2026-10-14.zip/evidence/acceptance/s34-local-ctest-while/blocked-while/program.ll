; ModuleID = 'G:\Hackathon-stage2-artifacts\project19\20261014-development\acceptance\s34-local-ctest-while\blocked-while.c'
source_filename = "G:\\Hackathon-stage2-artifacts\\project19\\20261014-development\\acceptance\\s34-local-ctest-while\\blocked-while.c"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-windows-msvc19.44.35228"

; Function Attrs: noinline nounwind optnone uwtable
define dso_local i32 @factor(ptr noundef %0, ptr noundef %1, i32 noundef %2, i32 noundef %3) #0 {
  %5 = alloca i32, align 4
  %6 = alloca i32, align 4
  %7 = alloca ptr, align 8
  %8 = alloca ptr, align 8
  %9 = alloca i32, align 4
  %10 = alloca i32, align 4
  %11 = alloca i32, align 4
  %12 = alloca i32, align 4
  %13 = alloca i32, align 4
  %14 = alloca i32, align 4
  %15 = alloca i32, align 4
  %16 = alloca i32, align 4
  %17 = alloca i32, align 4
  store i32 %3, ptr %5, align 4
  store i32 %2, ptr %6, align 4
  store ptr %1, ptr %7, align 8
  store ptr %0, ptr %8, align 8
  store i32 0, ptr %9, align 4
  br label %18

18:                                               ; preds = %213, %4
  %19 = load i32, ptr %9, align 4
  %20 = load i32, ptr %6, align 4
  %21 = icmp slt i32 %19, %20
  br i1 %21, label %22, label %217

22:                                               ; preds = %18
  %23 = load i32, ptr %9, align 4
  %24 = load i32, ptr %5, align 4
  %25 = add nsw i32 %23, %24
  %26 = load i32, ptr %6, align 4
  %27 = icmp slt i32 %25, %26
  br i1 %27, label %28, label %32

28:                                               ; preds = %22
  %29 = load i32, ptr %9, align 4
  %30 = load i32, ptr %5, align 4
  %31 = add nsw i32 %29, %30
  br label %34

32:                                               ; preds = %22
  %33 = load i32, ptr %6, align 4
  br label %34

34:                                               ; preds = %32, %28
  %35 = phi i32 [ %31, %28 ], [ %33, %32 ]
  store i32 %35, ptr %10, align 4
  %36 = load i32, ptr %9, align 4
  store i32 %36, ptr %11, align 4
  br label %37

37:                                               ; preds = %210, %34
  %38 = load i32, ptr %11, align 4
  %39 = load i32, ptr %10, align 4
  %40 = icmp slt i32 %38, %39
  br i1 %40, label %41, label %213

41:                                               ; preds = %37
  %42 = load ptr, ptr %8, align 8
  %43 = load i32, ptr %11, align 4
  %44 = load i32, ptr %6, align 4
  %45 = mul nsw i32 %43, %44
  %46 = load i32, ptr %11, align 4
  %47 = add nsw i32 %45, %46
  %48 = sext i32 %47 to i64
  %49 = getelementptr inbounds double, ptr %42, i64 %48
  %50 = load double, ptr %49, align 8
  %51 = load ptr, ptr %7, align 8
  %52 = load i32, ptr %11, align 4
  %53 = load i32, ptr %6, align 4
  %54 = mul nsw i32 %52, %53
  %55 = load i32, ptr %11, align 4
  %56 = add nsw i32 %54, %55
  %57 = sext i32 %56 to i64
  %58 = getelementptr inbounds double, ptr %51, i64 %57
  %59 = load double, ptr %58, align 8
  %60 = fsub double %50, %59
  %61 = call double @sqrt(double noundef %60) #2
  %62 = load ptr, ptr %7, align 8
  %63 = load i32, ptr %11, align 4
  %64 = load i32, ptr %6, align 4
  %65 = mul nsw i32 %63, %64
  %66 = load i32, ptr %11, align 4
  %67 = add nsw i32 %65, %66
  %68 = sext i32 %67 to i64
  %69 = getelementptr inbounds double, ptr %62, i64 %68
  store double %61, ptr %69, align 8
  %70 = load i32, ptr %11, align 4
  %71 = add nsw i32 %70, 1
  store i32 %71, ptr %12, align 4
  br label %72

72:                                               ; preds = %206, %41
  %73 = load i32, ptr %12, align 4
  %74 = load i32, ptr %6, align 4
  %75 = icmp slt i32 %73, %74
  br i1 %75, label %76, label %210

76:                                               ; preds = %72
  %77 = load i32, ptr %12, align 4
  %78 = load i32, ptr %5, align 4
  %79 = add nsw i32 %77, %78
  %80 = load i32, ptr %6, align 4
  %81 = icmp slt i32 %79, %80
  br i1 %81, label %82, label %86

82:                                               ; preds = %76
  %83 = load i32, ptr %12, align 4
  %84 = load i32, ptr %5, align 4
  %85 = add nsw i32 %83, %84
  br label %88

86:                                               ; preds = %76
  %87 = load i32, ptr %6, align 4
  br label %88

88:                                               ; preds = %86, %82
  %89 = phi i32 [ %85, %82 ], [ %87, %86 ]
  store i32 %89, ptr %13, align 4
  %90 = load i32, ptr %12, align 4
  store i32 %90, ptr %14, align 4
  br label %91

91:                                               ; preds = %203, %88
  %92 = load i32, ptr %14, align 4
  %93 = load i32, ptr %13, align 4
  %94 = icmp slt i32 %92, %93
  br i1 %94, label %95, label %206

95:                                               ; preds = %91
  %96 = load ptr, ptr %7, align 8
  %97 = load i32, ptr %11, align 4
  %98 = load i32, ptr %6, align 4
  %99 = mul nsw i32 %97, %98
  %100 = load i32, ptr %11, align 4
  %101 = add nsw i32 %99, %100
  %102 = sext i32 %101 to i64
  %103 = getelementptr inbounds double, ptr %96, i64 %102
  %104 = load double, ptr %103, align 8
  %105 = load ptr, ptr %8, align 8
  %106 = load i32, ptr %14, align 4
  %107 = load i32, ptr %6, align 4
  %108 = mul nsw i32 %106, %107
  %109 = load i32, ptr %11, align 4
  %110 = add nsw i32 %108, %109
  %111 = sext i32 %110 to i64
  %112 = getelementptr inbounds double, ptr %105, i64 %111
  %113 = load double, ptr %112, align 8
  %114 = load ptr, ptr %7, align 8
  %115 = load i32, ptr %14, align 4
  %116 = load i32, ptr %6, align 4
  %117 = mul nsw i32 %115, %116
  %118 = load i32, ptr %11, align 4
  %119 = add nsw i32 %117, %118
  %120 = sext i32 %119 to i64
  %121 = getelementptr inbounds double, ptr %114, i64 %120
  %122 = load double, ptr %121, align 8
  %123 = fsub double %113, %122
  %124 = call double @division(double noundef %123, double noundef %104)
  %125 = load ptr, ptr %7, align 8
  %126 = load i32, ptr %14, align 4
  %127 = load i32, ptr %6, align 4
  %128 = mul nsw i32 %126, %127
  %129 = load i32, ptr %11, align 4
  %130 = add nsw i32 %128, %129
  %131 = sext i32 %130 to i64
  %132 = getelementptr inbounds double, ptr %125, i64 %131
  store double %124, ptr %132, align 8
  %133 = load i32, ptr %11, align 4
  %134 = add nsw i32 %133, 1
  store i32 %134, ptr %15, align 4
  br label %135

135:                                              ; preds = %199, %95
  %136 = load i32, ptr %15, align 4
  %137 = load i32, ptr %14, align 4
  %138 = icmp sle i32 %136, %137
  br i1 %138, label %139, label %203

139:                                              ; preds = %135
  %140 = load i32, ptr %15, align 4
  %141 = load i32, ptr %5, align 4
  %142 = add nsw i32 %140, %141
  %143 = load i32, ptr %14, align 4
  %144 = add nsw i32 %143, 1
  %145 = icmp slt i32 %142, %144
  br i1 %145, label %146, label %150

146:                                              ; preds = %139
  %147 = load i32, ptr %15, align 4
  %148 = load i32, ptr %5, align 4
  %149 = add nsw i32 %147, %148
  br label %153

150:                                              ; preds = %139
  %151 = load i32, ptr %14, align 4
  %152 = add nsw i32 %151, 1
  br label %153

153:                                              ; preds = %150, %146
  %154 = phi i32 [ %149, %146 ], [ %152, %150 ]
  store i32 %154, ptr %16, align 4
  %155 = load i32, ptr %15, align 4
  store i32 %155, ptr %17, align 4
  br label %156

156:                                              ; preds = %160, %153
  %157 = load i32, ptr %17, align 4
  %158 = load i32, ptr %16, align 4
  %159 = icmp slt i32 %157, %158
  br i1 %159, label %160, label %199

160:                                              ; preds = %156
  %161 = load ptr, ptr %7, align 8
  %162 = load i32, ptr %14, align 4
  %163 = load i32, ptr %6, align 4
  %164 = mul nsw i32 %162, %163
  %165 = load i32, ptr %17, align 4
  %166 = add nsw i32 %164, %165
  %167 = sext i32 %166 to i64
  %168 = getelementptr inbounds double, ptr %161, i64 %167
  %169 = load double, ptr %168, align 8
  %170 = load ptr, ptr %7, align 8
  %171 = load i32, ptr %17, align 4
  %172 = load i32, ptr %6, align 4
  %173 = mul nsw i32 %171, %172
  %174 = load i32, ptr %11, align 4
  %175 = add nsw i32 %173, %174
  %176 = sext i32 %175 to i64
  %177 = getelementptr inbounds double, ptr %170, i64 %176
  %178 = load double, ptr %177, align 8
  %179 = load ptr, ptr %7, align 8
  %180 = load i32, ptr %14, align 4
  %181 = load i32, ptr %6, align 4
  %182 = mul nsw i32 %180, %181
  %183 = load i32, ptr %11, align 4
  %184 = add nsw i32 %182, %183
  %185 = sext i32 %184 to i64
  %186 = getelementptr inbounds double, ptr %179, i64 %185
  %187 = load double, ptr %186, align 8
  %188 = call double @madd(double noundef %187, double noundef %178, double noundef %169)
  %189 = load ptr, ptr %7, align 8
  %190 = load i32, ptr %14, align 4
  %191 = load i32, ptr %6, align 4
  %192 = mul nsw i32 %190, %191
  %193 = load i32, ptr %17, align 4
  %194 = add nsw i32 %192, %193
  %195 = sext i32 %194 to i64
  %196 = getelementptr inbounds double, ptr %189, i64 %195
  store double %188, ptr %196, align 8
  %197 = load i32, ptr %17, align 4
  %198 = add nsw i32 %197, 1
  store i32 %198, ptr %17, align 4
  br label %156, !llvm.loop !8

199:                                              ; preds = %156
  %200 = load i32, ptr %5, align 4
  %201 = load i32, ptr %15, align 4
  %202 = add nsw i32 %201, %200
  store i32 %202, ptr %15, align 4
  br label %135, !llvm.loop !10

203:                                              ; preds = %135
  %204 = load i32, ptr %14, align 4
  %205 = add nsw i32 %204, 1
  store i32 %205, ptr %14, align 4
  br label %91, !llvm.loop !11

206:                                              ; preds = %91
  %207 = load i32, ptr %5, align 4
  %208 = load i32, ptr %12, align 4
  %209 = add nsw i32 %208, %207
  store i32 %209, ptr %12, align 4
  br label %72, !llvm.loop !12

210:                                              ; preds = %72
  %211 = load i32, ptr %11, align 4
  %212 = add nsw i32 %211, 1
  store i32 %212, ptr %11, align 4
  br label %37, !llvm.loop !13

213:                                              ; preds = %37
  %214 = load i32, ptr %5, align 4
  %215 = load i32, ptr %9, align 4
  %216 = add nsw i32 %215, %214
  store i32 %216, ptr %9, align 4
  br label %18, !llvm.loop !14

217:                                              ; preds = %18
  ret i32 0
}

; Function Attrs: nounwind
declare dso_local double @sqrt(double noundef) #1

; Function Attrs: noinline nounwind optnone uwtable
define internal double @division(double noundef %0, double noundef %1) #0 {
  %3 = alloca double, align 8
  %4 = alloca double, align 8
  store double %1, ptr %3, align 8
  store double %0, ptr %4, align 8
  %5 = load double, ptr %4, align 8
  %6 = load double, ptr %3, align 8
  %7 = fdiv double %5, %6
  ret double %7
}

; Function Attrs: noinline nounwind optnone uwtable
define internal double @madd(double noundef %0, double noundef %1, double noundef %2) #0 {
  %4 = alloca double, align 8
  %5 = alloca double, align 8
  %6 = alloca double, align 8
  store double %2, ptr %4, align 8
  store double %1, ptr %5, align 8
  store double %0, ptr %6, align 8
  %7 = load double, ptr %6, align 8
  %8 = load double, ptr %5, align 8
  %9 = fmul double %7, %8
  %10 = load double, ptr %4, align 8
  %11 = fadd double %9, %10
  ret double %11
}

attributes #0 = { noinline nounwind optnone uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nounwind "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { nounwind }

!llvm.dbg.cu = !{!0}
!llvm.module.flags = !{!2, !3, !4, !5, !6}
!llvm.ident = !{!7}

!0 = distinct !DICompileUnit(language: DW_LANG_C11, file: !1, producer: "clang version 21.1.0", isOptimized: false, runtimeVersion: 0, emissionKind: NoDebug, splitDebugInlining: false, nameTableKind: None)
!1 = !DIFile(filename: "G:\\Hackathon-stage2-artifacts\\project19\\20261014-development\\acceptance\\s34-local-ctest-while\\blocked-while.c", directory: "F:\\Hackathon\\projects\\19-dynamic-graph")
!2 = !{i32 2, !"Debug Info Version", i32 3}
!3 = !{i32 1, !"wchar_size", i32 2}
!4 = !{i32 8, !"PIC Level", i32 2}
!5 = !{i32 7, !"uwtable", i32 2}
!6 = !{i32 1, !"MaxTLSAlign", i32 65536}
!7 = !{!"clang version 21.1.0"}
!8 = distinct !{!8, !9}
!9 = !{!"llvm.loop.mustprogress"}
!10 = distinct !{!10, !9}
!11 = distinct !{!11, !9}
!12 = distinct !{!12, !9}
!13 = distinct !{!13, !9}
!14 = distinct !{!14, !9}
