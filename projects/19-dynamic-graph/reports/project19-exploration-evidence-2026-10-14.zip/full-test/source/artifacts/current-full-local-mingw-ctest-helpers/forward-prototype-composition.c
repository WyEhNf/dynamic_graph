static double h(double);
int transform(const double*a,double*l,int n){for(int i=0;i<n*n;++i)l[i]=h(h(a[i]));return 0;}
static double h(double x){return x*0.5;}