from pathlib import Path
import datetime,hashlib,json,shutil,sys
P=Path('F:/Hackathon/projects/19-dynamic-graph');R=Path(__file__).resolve().parent
sys.path.insert(0,'G:/Hackathon-stage2-artifacts/project19/20261013-overnight/structured-owned-reuse')
from archive_members import members
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
baseline=Path('G:/Hackathon-stage2-artifacts/project19/20261014-exploration/full-test')
old=json.loads((baseline/'report.json').read_text())
names=set(old['source_sha256'])
for folder in ('src','tools','tests'):
    for p in (P/folder).rglob('*'):
        if p.is_file() and p.suffix in ('.py','.cpp','.hpp','.h','.ps1'):names.add(p.relative_to(P).as_posix())
frozen=R/'source';frozen.mkdir(exist_ok=False)
sources={}
for name in sorted(names):
    src=P/name;target=frozen/name;target.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(src,target);sources[name]=sha(target)
report=dict(status='validated_not_installed',created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
  source_count=len(sources),source_sha256=sources,profiles={},native_source_changes={k:dict(old=v,new=sources[k]) for k,v in old['source_sha256'].items() if k.startswith('src/') and v!=sources[k]})
assert set(report['native_source_changes'])=={'src/runtime.cpp'}
for profile,build,previous in [('local',R/'build',baseline/'build-local-mingw'),('memory',R/'build-memory',baseline/'build-memory-mingw')]:
    _,new_hash,_=members(build/'libcholesky_core.a');_,old_hash,_=members(previous/'libcholesky_core.a')
    assert set(new_hash)==set(old_hash)
    changed=[name for name in new_hash if new_hash[name]!=old_hash[name]]
    assert changed==['runtime.cpp.obj'],changed
    for path in ('CMakeCache.txt','CMakeFiles/cholesky_core.dir/flags.make','CMakeFiles/cholesky_core.dir/link.txt','CMakeFiles/cholesky_runtime.dir/flags.make','CMakeFiles/cholesky_runtime.dir/link.txt'):
        target=R/'build-provenance'/profile/path;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(build/path,target)
    report['profiles'][profile]=dict(runtime=str(build/'cholesky_runtime.exe'),runtime_sha256=sha(build/'cholesky_runtime.exe'),
       core_sha256=sha(build/'libcholesky_core.a'),raw_object_sha256=new_hash,changed_raw_objects_from_s33=changed,
       total_raw_objects=len(new_hash),baseline_build=str(previous))
(R/'release-manifest.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in report.items() if k not in ('source_sha256',)},indent=2))
