#include <math.h>
static double division(double x,double y){return x/y;}
static double madd(double x,double y,double z){return x*y+z;}
void factor(const double*a,double*l,int n){
int i=0;while(i<=n-1){
  l[i*n+i]=sqrt(a[i*n+i]-l[i*n+i]);
  int j=i+1;while(j<n){
    l[j*n+i]=division(a[j*n+i]-l[j*n+i],l[i*n+i]);
    int k=i+1;while(k<j+1){l[j*n+k]=madd(l[j*n+i],l[k*n+i],l[j*n+k]);++k;}
    j=j+2;
  }i+=1;
}}
