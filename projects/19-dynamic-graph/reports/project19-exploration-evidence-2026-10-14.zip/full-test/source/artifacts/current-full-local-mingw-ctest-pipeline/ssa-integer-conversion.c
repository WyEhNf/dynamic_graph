static double conversion(double x){int truncated=x; double converted=truncated;return converted/2.0;}
int transform(const double*a,double*l,int n){for(int i=0;i<n*n;++i)l[i]=conversion(a[i]);return 0;}
