static double h(double x,double y){return x+y+x;}
int transform(const double*a,double*l,int n){for(int i=0;i<n*n;++i)l[i]=h(h(a[i],a[0]),h(a[0],a[i]));return 0;}