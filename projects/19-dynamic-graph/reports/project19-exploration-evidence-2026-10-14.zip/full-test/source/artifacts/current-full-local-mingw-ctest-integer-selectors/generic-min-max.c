static int choose(int x,int y){return x<y?x:y;}
static int greatest(int x,int y){return x>y?x:y;}
int transform(const double*a,double*l,int n){for(int i=0;i<n*n;++i)l[i]=greatest(choose(i,n),i-n);return 0;}