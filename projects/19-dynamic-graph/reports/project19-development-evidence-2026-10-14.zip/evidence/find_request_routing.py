from pathlib import Path
r=Path(__file__).resolve().parent/'official'
for p in sorted(r.glob('frontend-*.js')):
 s=p.read_text(encoding='utf-8')
 for t in ('chasparkcontentservice','baseURL:','__baseDomain','interceptors.request','/chasiwu','getCompetitionsApi'):
  hits=[];k=s.find(t)
  while k>=0 and len(hits)<3:hits.append(s[max(0,k-150):k+400]);k=s.find(t,k+len(t))
  if hits:print(p.name,t,*hits,sep='\n',flush=True)
