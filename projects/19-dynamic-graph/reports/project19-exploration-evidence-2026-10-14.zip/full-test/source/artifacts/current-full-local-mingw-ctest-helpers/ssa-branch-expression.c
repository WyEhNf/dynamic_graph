static double h(double x){double y=x*0.5;return y>0?y+y:-y;}
int transform(const double*a,double*l,int n){for(int i=0;i<n*n;++i)l[i]=h(a[i]);return 0;}