from pathlib import Path
import datetime,hashlib,json,os,subprocess
ROOT=Path(__file__).resolve().parent;P=Path('F:/Hackathon/projects/19-dynamic-graph');OUT=ROOT/'encoding-test';OUT.mkdir(exist_ok=True)
assert not (OUT/'report.json').exists()
env=dict(os.environ,PATH='E:/mingw64/bin;C:/Program Files/LLVM/bin;'+os.environ.get('PATH',''),TEMP=str(OUT),TMP=str(OUT),PYTHONUTF8='1',PYTHONIOENCODING='utf-8')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
r=dict(status='running',started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='Current explicit schema2/3 and dag/table/expanded minimum selection from six independently analyzed sources. Compressed input rejection verified because both actual presets compile it OFF.',profiles=[],compressed_rejections=[])
def save():(OUT/'report.json').write_text(json.dumps(r,indent=2)+'\n',encoding='utf-8')
save()
for label,exe in [('local',P/'build/cholesky_runtime.exe'),('memory',ROOT/'full-test/build-memory-mingw/cholesky_runtime.exe')]:
 cmd=[str(P/'.venv/Scripts/python.exe'),str(P/'tools/test_smallest_metadata_stage2.py'),'--runtime',str(exe),'--output-dir',str(OUT/label)]
 x=subprocess.run(cmd,env=env,cwd=P,capture_output=True,text=True);(OUT/(label+'.log')).write_text(x.stdout+x.stderr,encoding='utf-8');assert x.returncode==0,(label,x.stderr,x.stdout[-2000:])
 q=json.loads((OUT/label/'report.json').read_text(encoding='utf-8'));assert q['passed'];r['profiles'].append(dict(profile=label,command=cmd,runtime_sha256=sha(exe),success_runs=q['runtime_comparisons'],conflicting_options_rejected=q['conflicting_cli_options_rejected'],report_sha256=sha(OUT/label/'report.json')));save()
 import zlib,struct
 raw=(OUT/label/'scalar/minimum.meta').read_bytes();payload=zlib.compress(raw,9);meta=OUT/(label+'-compressed.meta');meta.write_bytes(b'DYNCHZ01'+struct.pack('<II',len(raw),len(payload))+payload)
 dst=OUT/(label+'-compressed-output.bin');dst.write_bytes(b'preserved-prior-output')
 c=[str(exe),'--metadata',str(meta),'--input',str(OUT/label/'scalar/dense-input.bin'),'--output',str(dst)];x=subprocess.run(c,env=env,capture_output=True,text=True)
 assert x.returncode!=0 and 'unsupported metadata schema' in x.stderr and dst.read_bytes()==b'preserved-prior-output' and not dst.with_suffix(dst.suffix+'.partial').exists(),x.stderr
 r['compressed_rejections'].append(dict(profile=label,command=c,returncode=x.returncode,error=x.stderr.strip(),prior_output_preserved=True,partial_absent=True));save();print(json.dumps(dict(profile=label,passed=True,successes=q['runtime_comparisons'])),flush=True)
r.update(status='completed',passed=True,success_runs=sum(x['success_runs'] for x in r['profiles']),expected_rejections=sum(x['conflicting_options_rejected'] for x in r['profiles'])+len(r['compressed_rejections']),finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());save()
