from pathlib import Path
import json,re,urllib.request
r=Path(__file__).resolve().parent/'official';s=(r/'frontend-6.js').read_text(encoding='utf-8')
terms=['getRaceDetail','getCompetitionDetail','getRaceUnionDetail','question-detail','competition-detail','baseURL']
for t in terms:
 k=s.find(t)
 if k>=0:print(t,s[max(0,k-90):k+550],flush=True)
# Read only endpoint declarations shipped by the public frontend.
for m in re.finditer(r'\w*(?:Detail|detail)\w*Api:',s):print(s[m.start():m.start()+180],flush=True)
