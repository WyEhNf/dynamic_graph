"""Preregistered same-host actual OpenBLAS comparison after full tests end."""
from pathlib import Path
import datetime,hashlib,json,os,statistics,subprocess,sys,time
ROOT=Path(__file__).resolve().parent;PROJECT=Path('F:/Hackathon/projects/19-dynamic-graph')
OUT=ROOT/'industry-benchmark';OUT.mkdir(exist_ok=True)
assert not (OUT/'report.json').exists()
sys.path.insert(0,str(PROJECT/'tools'))
from windows_file_resource_probe_stage2 import monitored_run
def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
    return h.hexdigest()
assert json.loads((ROOT/'full-test/report.json').read_text(encoding='utf-8'))['status']=='completed','Avoid CPU contention with full tests'
runtime=PROJECT/'build/cholesky_runtime.exe';expected='912c9fec8ac5e1793d6217afc5c3b09f49a8b8e536f273eeaef9b94a69072eba';assert sha(runtime)==expected
metadata=Path('G:/Hackathon-stage2-artifacts/project19/20261013-evening/native-optimization/official.meta')
freeze=Path('G:/Hackathon-stage2-artifacts/project19/20261013-overnight/lifecycle/acceptance-freeze/plan.json')
frozen=json.loads(freeze.read_text(encoding='utf-8'))
d4099=next(c for c in frozen['cases'] if c['name']=='dense-4099')
maximum=PROJECT/'artifacts/maximum-dense-oracle';mx=json.loads((maximum/'reference-provenance.json').read_text(encoding='utf-8'))
bandroot=PROJECT/'artifacts/band-maximum-reference';br=json.loads((bandroot/'reference-report.json').read_text(encoding='utf-8'))
inputs=[dict(label='dense4099',n=4099,input=d4099['input'],oracle=d4099['oracle'],input_sha256=d4099['input_sha256'],oracle_sha256=d4099['oracle_sha256'],kind='dense',threads=[1,4,16]),
    dict(label='dense10000',n=10000,input=str(maximum/'input.bin'),oracle=str(maximum/'oracle.bin'),input_sha256=mx['input_sha256'],oracle_sha256=mx['oracle_sha256'],kind='dense',threads=[1,4,16]),
    dict(label='band7-10000',n=10000,input=str(bandroot/'input.bin'),oracle=str(bandroot/'oracle.bin'),input_sha256=br['input_sha256'],oracle_sha256=br['oracle_sha256'],kind='band7',threads=[1,16])]
for c in inputs:assert sha(c['input'])==c['input_sha256'] and sha(c['oracle'])==c['oracle_sha256']
env=dict(os.environ,PATH='E:/mingw64/bin;'+os.environ.get('PATH',''),TEMP=str(OUT),TMP=str(OUT),PYTHONUTF8='1',PYTHONIOENCODING='utf-8')
os.environ.update(env)
python='C:/Users/admin/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe'
report=dict(status='running',started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),runtime_sha256=expected,metadata_sha256=sha(metadata),script_sha256=sha(Path(__file__)),openblas_driver_sha256=sha(ROOT/'openblas_case.py'),
    plan=dict(inputs=inputs,pairs=3,order='Native/BLAS, BLAS/Native, Native/BLAS',warmup='None; fresh process each run, all startup/cold observations retained',
        comparison='Same frozen original-C data and same requested1/4/16 thread budgets. Native total compute and kernel timer both compared with pure library factor and documented wrapper timer. Different numerical and API contracts: never rank BLAS as an acceptable strict-source substitute.',
        controls='Actual library config/core/thread count recorded; CPU host shared, not pinned, no thermal isolation. Library peak memory includes retained original-C memmap for numerical checks, so not compared with native memory.'),records=[],summary=[])
def save():(OUT/'report.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
save()
for c in inputs:
    for threads in c['threads']:
        label=c['label']+'-t'+str(threads)
        for pair in range(3):
            for variant in (('native','blas') if pair%2==0 else ('blas','native')):
                tag=f'{label}-p{pair}-{variant}'
                if variant=='native':
                    dst=OUT/(tag+'.bin');cmd=[str(runtime),'--metadata',str(metadata),'--input',c['input'],'--output',str(dst)]
                    if threads!=1:cmd+=['--scheduler','parallel','--threads',str(threads)]
                else:cmd=[python,str(ROOT/'openblas_case.py'),'--input',c['input'],'--oracle',c['oracle'],'--threads',str(threads),'--kind',c['kind']]
                start=time.perf_counter();p,res=monitored_run(cmd,OUT/(tag+'.stdout'),OUT/(tag+'.stderr'),check=False,timeout=180);wall=time.perf_counter()-start
                assert p.returncode==0,(tag,p.stderr)
                m=json.loads(p.stdout)
                validation=None
                if variant=='native':
                    h=sha(dst);assert h==c['oracle_sha256'];validation=dict(original_C_full_file_sha256=h,bytes=dst.stat().st_size)
                    assert m['vm_steps']==0 and m['worker_threads_max']==(1 if c['kind']=='band7' else threads)
                else:assert m['threads_actual']==threads and m['info']==0
                report['records'].append(dict(case=label,n=c['n'],kind=c['kind'],threads=threads,pair=pair,variant=variant,metrics=m,resources=res,wall_seconds=wall,command=cmd,native_exact_validation=validation));save()
        rows=[r for r in report['records'] if r['case']==label]
        nat=[r['metrics'] for r in rows if r['variant']=='native'];lib=[r['metrics'] for r in rows if r['variant']=='blas']
        med=lambda a,k:statistics.median(x[k] for x in a)
        summary=dict(case=label,n=c['n'],kind=c['kind'],threads=threads,native_compute_ms=med(nat,'compute_ms'),native_kernel_ms=med(nat,'kernel_ms'),blas_factor_ms=med(lib,'factor_ms'),blas_wrapper_ms=med(lib,'wrapper_ms'),
            native_compute_over_blas_factor=med(nat,'compute_ms')/med(lib,'factor_ms'),native_compute_over_blas_wrapper=med(nat,'compute_ms')/med(lib,'wrapper_ms'),
            native_gflops=(c['n']**3/3)/(med(nat,'compute_ms')*1e6) if c['kind']=='dense' else None,
            blas_gflops=med(lib,'equivalent_dense_gflops') if c['kind']=='dense' else None,
            blas_bit_mismatches_lower=lib[0]['bit_mismatches_lower'],blas_inband_bit_mismatches=lib[0]['inband_bit_mismatches'],blas_relative_factor_error_to_C=lib[0]['relative_frobenius_error_to_C'],
            native_paired_compute_ms=[x['compute_ms'] for x in nat],blas_paired_factor_ms=[x['factor_ms'] for x in lib],blas_paired_wrapper_ms=[x['wrapper_ms'] for x in lib],
            library_core=lib[0]['core'],library_config=lib[0]['config'])
        report['summary'].append(summary);save();print(json.dumps(summary),flush=True)
assert sha(runtime)==expected
report.update(status='completed',passed=True,processes=len(report['records']),finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());save()
print(json.dumps(dict(passed=True,processes=len(report['records']),production_modified=False)),flush=True)
